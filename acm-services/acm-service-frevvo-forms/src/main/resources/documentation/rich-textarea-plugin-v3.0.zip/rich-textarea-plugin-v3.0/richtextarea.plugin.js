var _debugger = false;
var selector = rtaSelector ? rtaSelector : 'div.rta_container span.f-message:not([style="display: none;"])';
var editors = [];
var updateEditors = true;

function debug(value, _debuggerLocal)
{
	if (_debugger && _debuggerLocal != false)
	{
		console.log(value);
	}
}

setInterval('refresh()', rtaRefreshMilliseconds ? rtaRefreshMilliseconds : 500);

function refresh()
{
	debug('refresh ->', false);
	
	addSummernoteBehavior();
	
	if (updateEditors)
	{
		updateEditorsContent();
	}
}

function addSummernoteBehavior()
{
	debug('addSummernoteBehavior ->', false);
	
	var options = {
					  oninit: function() 
					  {
						debug('Summernote initialization', true);
					  },
					  onfocus: function(e) {
						debug('Summernote focus', true);
						
						updateEditors = false;
					  },
					  onblur: function(e) 
					  {
						debug('Summernote blur', true);
						
						var changeEvent = document.createEvent("Event")
						changeEvent.initEvent("change", true, true);
						
						var $textarea = frevvo_jQuery(this).parent().parent().parent().next().find('textarea');
						var html = frevvo_jQuery(this).html();
						
						// Dispatching change event via jQuery cannot take action on Frevvo side.
						// For that reason text area is converted to DOM element and dispatched change event from that element
						var domTextarea = $textarea.get(0);
						
						domTextarea.value = html;
						domTextarea.dispatchEvent(changeEvent);
						
						updateEditors = true;
					  }
				  };
	
	if (rtaSummernoteOptions)
	{
		options = frevvo_jQuery.extend({}, options, rtaSummernoteOptions);
	}
	
	frevvo_jQuery(selector).each(function(){
		var $editor = frevvo_jQuery(this);
		$editor.summernote(options);
		editors.push($editor);
	});
}

function updateEditorsContent()
{
	debug('updateEditorsContent ->', false);
	
	for (var i = 0; i < editors.length; i++)
	{
		debug('updateEditorsContent -> ' + editors[i].code(), true);
		
		var $textarea = editors[i].parent().parent().next().find('textarea');
		var html = $textarea.value;
		
		editors[i].code(html);
	}
}