/**
 * App.Model
 *
 * @author jwu
 */
App.Model = {
    create : function() {
    }
    ,onInitialized: function() {
    }

};




