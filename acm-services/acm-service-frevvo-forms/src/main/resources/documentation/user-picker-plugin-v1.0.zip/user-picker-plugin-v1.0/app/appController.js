/**
 * App.Controller
 *
 * @author jwu
 */
App.Controller = {
    create : function() {
    }
    ,onInitialized: function() {
    }

};




