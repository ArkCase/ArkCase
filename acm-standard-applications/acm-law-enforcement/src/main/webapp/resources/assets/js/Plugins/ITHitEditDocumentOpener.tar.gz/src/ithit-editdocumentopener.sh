#!/bin/bash

python -O /usr/bin/document_opener.pyo "$@"

