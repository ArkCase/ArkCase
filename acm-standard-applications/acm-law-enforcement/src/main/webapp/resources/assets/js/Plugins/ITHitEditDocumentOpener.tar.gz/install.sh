#! /bin/bash

if [[ $EUID -ne 0 ]]; then
    echo " ============================================================"
    echo " !!!!!!!!!! This script must be run as root !!!!!!!!!!!!!!!! " 1>&2
    echo " ============================================================"
    exit 1
fi
echo "Start instalation"
echo "Add files ..."

cp -f "src/gui.pyo" "/usr/bin/"
ln -fs "/usr/bin/gui.pyo" "/usr/bin/gui"

cp -f "src/document_opener.pyo" "/usr/bin/"
ln -fs "/usr/bin/document_opener.pyo" "/usr/bin/document_opener"

cp -f "src/operations.pyo" "/usr/bin/"
ln -fs "/usr/bin/operations.pyo" "/usr/bin/operations"

cp -f "src/set_mount_disk.pyo" "/usr/bin/"
ln -fs "/usr/bin/set_mount_disk.pyo" "/usr/bin/set_mount_disk"

cp -f "src/ithit-editdocumentopener.sh" "/usr/bin/"

cp -f "src/ithit-editdocumentopener.desktop" "/usr/share/applications/" 
cp -f "src/ithit-editdocumentopener.xml" "/usr/share/mime/packages/" 

echo "Update MIME object ..."
xdg-mime install --mode system /usr/share/mime/packages/ithit-editdocumentopener.xml
update-mime-database /usr/share/mime/
