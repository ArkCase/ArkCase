#! /bin/bash

if [[ $EUID -ne 0 ]]; then
	echo " ============================================================"
   	echo " !!!!!!!!!! This script must be run as root !!!!!!!!!!!!!!!! " 1>&2
   	echo " ============================================================"
   exit 1
fi
echo "Start unistall ..."

echo "Remove files ..."

FILES="
/usr/bin/gui 
/usr/bin/gui.pyo
/usr/bin/document_opener 
/usr/bin/document_opener.pyo
/usr/bin/operations 
/usr/bin/operations.pyo
/usr/bin/set_mount_disk 
/usr/bin/set_mount_disk.pyo
/usr/share/applications/ithit-editdocumentopener.desktop
/usr/bin/ithit-editdocumentopener.sh"

for f in $FILES
do
	echo "Processing $f"
	if test -f $f; then rm $f; fi
done

echo "uninstall MIME object ..."

file_ln="/usr/share/mime/packages/ithit-editdocumentopener.xml"
xdg-mime uninstall --mode system $file_ln

update-mime-database /usr/share/mime/

echo "Done "
