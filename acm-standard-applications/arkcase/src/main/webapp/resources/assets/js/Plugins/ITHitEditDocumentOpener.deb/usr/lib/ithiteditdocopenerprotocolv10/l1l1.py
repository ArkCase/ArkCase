#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1lll = sys.version_info [0] == 2
l1lll1ll = 2048
l111l = 7
def l1lll1l1 (l11l1l1):
    global l11ll11
    l1l1ll1 = ord (l11l1l1 [-1])
    l1l11l1 = l11l1l1 [:-1]
    l11ll = l1l1ll1 % len (l1l11l1)
    l11 = l1l11l1 [:l11ll] + l1l11l1 [l11ll:]
    if l1l1lll:
        l1ll1ll = l1ll1l11 () .join ([unichr (ord (char) - l1lll1ll - (l1lll + l1l1ll1) % l111l) for l1lll, char in enumerate (l11)])
    else:
        l1ll1ll = str () .join ([chr (ord (char) - l1lll1ll - (l1lll + l1l1ll1) % l111l) for l1lll, char in enumerate (l11)])
    return eval (l1ll1ll)
import re
class l1ll11l(Exception):
    def __init__(self, *args,**kwargs):
        self.l1llllll1 = kwargs.get(l1lll1l1 (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡧࡵࠥࢬ"))
        self.l1111 = kwargs.get(l1lll1l1 (u"ࠤࡶࡩࡷࡼࡥࡳࡗࡵ࡭ࠧࢭ"))
        l1llll1l1 = self.l1lll1l1l(args)
        if l1llll1l1:
            args=args+ l1llll1l1
        self.args = [a for a in args]
    def l1lll1l1l(self, *args):
        l1llll1l1=None
        l1l11l1l = args[0][0]
        if re.search(l1lll1l1 (u"ࠥࡒࡴࠦࡋࡦࡴࡥࡩࡷࡵࡳࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠦࡡࡷࡣ࡬ࡰࡦࡨ࡬ࡦࠤࢮ"), l1l11l1l):
            l1llll1l1 = (l1lll1l1 (u"ࠫ࡞ࡵࡵࠡࡪࡤࡺࡪࠦࡤࡢࡸࡩࡷ࠷ࠦࡶࠦࡵࠣ࡭ࡳࡹࡴࡢ࡮࡯ࡩࡩ࠴ࠠࡊࡰࠣࡧࡦࡹࡥࠡࡻࡲࡹࡷࠦࡳࡦࡴࡹࡩࡷࠦࡩࡴࠢࡸࡷ࡮ࡴࡧࠡࡐࡗࡐࡒࠦ࡯ࡳࠢࡎࡩࡷࡨࡥࡳࡱࡶࠤࡦࡻࡴࡩࡧࡱࡸ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡪࡡࡷࡨࡶ࠶ࠥ࠷࠮࠶࠰࠵ࠤࡴࡸࠠ࡭ࡣࡷࡩࡷࠦࡩࡴࠢࡵࡩࡶࡻࡩࡳࡧࡧ࠲ࠬࢯ") %self.l1llllll1
                            ,)
        return l1llll1l1
class l1llll111(Exception):
    def __init__(self, *args, **kwargs):
        l1llll1l1 = self.l1lll1l1l(args)
        if l1llll1l1:
            args = args + l1llll1l1
        self.args = [a for a in args]
    def l1lll1l1l(self, *args):
        s = l1lll1l1 (u"ࠧࠦ࠭ࠡࡈࡲࡶࠥࡕࡰࡦࡰࡖࡹࡸ࡫ࠠࡱ࡮ࡨࡥࡸ࡫ࠠࡪࡰࡶࡸࡦࡲ࡬ࠡࡆࡤࡺ࡫ࡹ࠲ࠡࡀࡀ࠵࠳࠻࠮࠳ࠢࡹࡩࡷࡹࡩࡰࡰ࠱ࠤࡡࡴ࡙ࡰࡷࠣࡧࡦࡴࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢ࡬ࡸࠥ࡬ࡲࡰ࡯ࠣ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸࡵࡦࡵࡹࡤࡶࡪ࠴࡯ࡱࡧࡱࡷࡺࡹࡥ࠯ࡱࡵ࡫࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠮ࡩࡶࡰࡰࡄࡶࡲࡰ࡬ࡨࡧࡹࡃࡨࡰ࡯ࡨࠩ࠸ࡇࡓࡢࡷࡨࡶࡱࡧ࡮ࡥࠨࡳࡥࡨࡱࡡࡨࡧࡀࡨࡦࡼࡦࡴ࠴ࠣࡠࡳࠨࢰ")
        s += l1lll1l1 (u"ࠨࠠ࠮ࠢࡉࡳࡷࠦࡄࡦࡤ࡬ࡥࡳࠦࡤࡪࡵࡷࡶ࡮ࡨࡵࡵ࡫ࡲࡲࡸࠦࠨࡖࡤࡸࡲࡹࡻࠬࠡࡍࡸࡦࡺࡴࡴࡶ࠮ࠣࡩࡹࡩ࠮ࠪࠢ࡬ࡲࠥࡩ࡯࡯ࡵࡲࡰࡪࠦࡷࡪࡶ࡫ࠤࡷࡵ࡯ࡵࠢࡳࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠠࡦࡺࡨࡧࡺࡺࡥࠡ࡞ࠥࡷࡺࡪ࡯ࠡࡣࡳࡸ࠲࡭ࡥࡵࠢ࡬ࡲࡸࡺࡡ࡭࡮ࠣࡨࡦࡼࡦࡴ࠴࡟ࠦࠥࡢ࡮ࠣࢱ")
        return (s,)
class l1111111(Exception):
    pass
class l111111(Exception):
    pass
class l111111l(Exception):
    def __init__(self, message, l11111l1, url):
        super(l111111l,self).__init__(message)
        self.l11111l1 = l11111l1
        self.url = url
class l1lllllll(Exception):
    pass
class l1lll1lll(Exception):
    pass
class l1111l1l(Exception):
    pass
class l1llll1ll(Exception):
    pass
class l1llll11l(Exception):
    pass
class l11111ll(Exception):
    pass
class l1111l11(Exception):
    pass
class l1lllll11(Exception):
    pass
class l1lll1ll1(Exception):
    pass
class l1lllll1l(Exception):
    pass
class l1111ll1(Exception):
    pass
class l11l11ll(Exception):
    pass