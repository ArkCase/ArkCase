#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1lll = sys.version_info [0] == 2
l1lll1ll = 2048
l111l = 7
def l1lll1l1 (l11l1l1):
    global l11ll11
    l1l1ll1 = ord (l11l1l1 [-1])
    l1l11l1 = l11l1l1 [:-1]
    l11ll = l1l1ll1 % len (l1l11l1)
    l11 = l1l11l1 [:l11ll] + l1l11l1 [l11ll:]
    if l1l1lll:
        l1ll1ll = l1ll1l11 () .join ([unichr (ord (char) - l1lll1ll - (l1lll + l1l1ll1) % l111l) for l1lll, char in enumerate (l11)])
    else:
        l1ll1ll = str () .join ([chr (ord (char) - l1lll1ll - (l1lll + l1l1ll1) % l111l) for l1lll, char in enumerate (l11)])
    return eval (l1ll1ll)
import logging
from logging.handlers import SysLogHandler
import io, sys
import os, pwd, grp
import urllib.parse, urllib.error
import json
l1lllll1ll=logging.WARNING
logger = logging.getLogger(l1lll1l1 (u"ࠣ࡫ࡷ࡬࡮ࡺࡥࡥ࡫ࡷࡨࡴࡩࡵ࡮ࡧࡱࡸࡴࡶࡥ࡯ࡧࡵ࠲ࡸ࡫ࡴࡠ࡯ࡲࡹࡳࡺ࡟ࡥ࡫ࡶ࡯ࠧॾ"))
logger.setLevel(l1lllll1ll)
l1l111ll = SysLogHandler(address=l1lll1l1 (u"ࠩ࠲ࡨࡪࡼ࠯࡭ࡱࡪࠫॿ"))
formatter = logging.Formatter(l1lll1l1 (u"ࠪࠩ࠭ࡴࡡ࡮ࡧࠬࡷࠥࠫࠨ࡭ࡧࡹࡩࡱࡴࡡ࡮ࡧࠬࡷ࠿ࠫࠨࡧ࡫࡯ࡩࡳࡧ࡭ࡦࠫࡶ࠾ࠪ࠮࡬ࡪࡰࡨࡲࡴ࠯ࡤࠡ࠯࠰ࠤࠪ࠮࡭ࡦࡵࡶࡥ࡬࡫ࠩࡴࠩঀ"))
l1l111ll.setFormatter(formatter)
logger.addHandler(l1l111ll)
ch = logging.StreamHandler()
ch.setLevel(l1lllll1ll)
logger.addHandler(ch)
class l1llll111l(io.FileIO):
    l1lll1l1 (u"ࠦࠧࠨࡔࡩ࡫ࡶࠤࡨࡲࡡࡴࡵࠣࡩࡽࡺࡥ࡯ࡦࡶࠤ࡫࡯࡬ࡦࠢ࡬ࡲࠥࡵࡲࡥࡧࡵࠤࡹࡵࠠࡪ࡯ࡳࡰࡪࡳࡥ࡯ࡶࠣࡥࠥ࡬ࡩ࡭ࡧࠣࡶࡪࡧࡤࡦࡴ࠲ࡻࡷ࡯ࡴࡦࡴࠍࠤࠥࠦࠠࡧࡱࡵࠤ࡫࡯࡬ࡦࠢࡣ࠳ࡪࡺࡣ࠰ࡨࡶࡸࡦࡨࡠࠋࠢࠣࠤࠥࠨࠢࠣঁ")
    class Entry(object):
        l1lll1l1 (u"ࠧࠨࠢࡆࡰࡷࡶࡾࠦࡣ࡭ࡣࡶࡷࠥࡸࡥࡱࡴࡨࡷࡪࡴࡴࡴࠢࡤࠤࡳࡵ࡮࠮ࡥࡲࡱࡲ࡫࡮ࡵࠢ࡯࡭ࡳ࡫ࠠࡰࡰࠣࡸ࡭࡫ࠠࡡ࠱ࡨࡸࡨ࠵ࡦࡴࡶࡤࡦࡥࠦࡦࡪ࡮ࡨࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣং")
        def __init__(self, device, l1lll1ll11, l1lllll111,
                     options, d=0, p=0):
            self.device = device
            self.l1lll1ll11 = l1lll1ll11
            self.l1lllll111 = l1lllll111
            if not options:
                options = l1lll1l1 (u"ࠨࡤࡦࡨࡤࡹࡱࡺࡳࠣঃ")
            self.options = options
            self.d = int(d)
            self.p = int(p)
        def __eq__(self, o):
            return str(self) == str(o)
        def __str__(self):
            return l1lll1l1 (u"ࠢࡼࡿࠣࡿࢂࠦࡻࡾࠢࡾࢁࠥࢁࡽࠡࡽࢀࠦ঄").format(self.device,
                                              self.l1lll1ll11,
                                              self.l1lllll111,
                                              self.options,
                                              self.d,
                                              self.p)
    l1llll1l11 = os.path.join(os.path.sep, l1lll1l1 (u"ࠨࡧࡷࡧࠬঅ"), l1lll1l1 (u"ࠩࡩࡷࡹࡧࡢࠨআ"))
    def __init__(self, path=None):
        if path:
            self._1lll1l1l1 = path
        else:
            self._1lll1l1l1 = self.l1llll1l11
        super(l1llll111l, self).__init__(self._1lll1l1l1, l1lll1l1 (u"ࠪࡶࡧ࠱ࠧই"))
    def _1llll11l1(self, line):
        return l1llll111l.Entry(*[x for x in line.strip(l1lll1l1 (u"ࠦࡡࡴࠢঈ")).split() if x not in (l1lll1l1 (u"ࠬ࠭উ"), None)])
    @property
    def entries(self):
        self.seek(0)
        for line in self.readlines():
            line = line.decode(l1lll1l1 (u"࠭ࡵࡴ࠯ࡤࡷࡨ࡯ࡩࠨঊ"))
            try:
                if line.strip() and not line.strip().startswith(l1lll1l1 (u"ࠢࠤࠤঋ")):
                    yield self._1llll11l1(line)
            except ValueError:
                pass
    def l1llll1ll1(self, attr, value):
        for entry in self.entries:
            l1lll11l11 = getattr(entry, attr)
            if l1lll11l11 == value:
                return entry
        return None
    def l1lll111l1(self, entry):
        if self.l1llll1ll1(l1lll1l1 (u"ࠨࡦࡨࡺ࡮ࡩࡥࠨঌ"), entry.device):
            return False
        self.write((str(entry) + l1lll1l1 (u"ࠩ࡟ࡲࠬ঍")).encode(l1lll1l1 (u"ࠪࡹࡸ࠳ࡡࡴࡥ࡬࡭ࠬ঎")))
        self.truncate()
        return entry
    def l1lll1l1ll(self, entry):
        self.seek(0)
        lines = [l.decode(l1lll1l1 (u"ࠫࡺࡹ࠭ࡢࡵࡦ࡭࡮࠭এ")) for l in self.readlines()]
        found = False
        for index, line in enumerate(lines):
            if line.strip() and not line.strip().startswith(l1lll1l1 (u"ࠧࠩࠢঐ")):
                if self._1llll11l1(line) == entry:
                    found = True
                    break
        if not found:
            return False
        lines.remove(line)
        self.seek(0)
        self.write(l1lll1l1 (u"࠭ࠧ঑").join(lines).encode(l1lll1l1 (u"ࠧࡶࡵ࠰ࡥࡸࡩࡩࡪࠩ঒")))
        self.truncate()
        return True
    @classmethod
    def l1lll11ll1(cls, l1lll1ll11, path=None):
        l1lll1l111 = cls(path=path)
        entry = l1lll1l111.l1llll1ll1(l1lll1l1 (u"ࠨ࡯ࡲࡹࡳࡺࡰࡰ࡫ࡱࡸࠬও"), l1lll1ll11)
        if entry:
            return l1lll1l111.l1lll1l1ll(entry)
        return False
    @classmethod
    def add(cls, device, l1lll1ll11, l1lllll111, options=None, path=None):
        return cls(path=path).l1lll111l1(l1llll111l.Entry(device,
                                                    l1lll1ll11, l1lllll111,
                                                    options=options))
class l1lll11l1l(object):
    def __init__(self, l1lll111ll):
        self.l1lll11lll=l1lll1l1 (u"ࠤ࠱ࡨࡦࡼࡦࡴ࠴ࠥঔ")
        self.l1lll1llll=l1lll1l1 (u"ࠥࡷࡪࡩࡲࡦࡶࡶࠦক")
        self.l1lll111ll=l1lll111ll
        self.l1llllll1l()
        self.l1llllll11()
        self.l1llll1lll()
        self.l11111111()
        self.l1lllll11l()
    def l1llllll1l(self):
        temp_file=open(l1llll1l1l,l1lll1l1 (u"ࠫࡷ࠭খ"))
        l11llll=temp_file.read()
        data=json.loads(l11llll)
        self.user=data[l1lll1l1 (u"ࠧࡻࡳࡦࡴࡢࡰࡴ࡭ࡩ࡯ࠤগ")]
        self.l1l1l1=data[l1lll1l1 (u"ࠨ࡭ࡰࡷࡱࡸࡕࡧࡴࡩࠤঘ")]
        self.l11l=data[l1lll1l1 (u"ࠢࡥ࡫ࡵࡔࡦࡺࡨࠣঙ")]
        self.l1111l1=data[l1lll1l1 (u"ࠣࡪࡲࡱࡪࡥࡦࡰ࡮ࡧࡩࡷࠨচ")]
        self.l1lll1lll1=data[l1lll1l1 (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥ࡬ࡰࡩ࡬ࡲࠧছ")]
        self.l1lll1l11l=data[l1lll1l1 (u"ࠥࡱࡴࡻ࡮ࡵࡡࡸࡷࡪࡸ࡟ࡱࡣࡶࡷࠧজ")]
    def l1llll1lll(self):
        l1ll1l=os.path.join(l1lll1l1 (u"ࠦ࠴ࠨঝ"),l1lll1l1 (u"ࠧࡻࡳࡳࠤঞ"),l1lll1l1 (u"ࠨࡳࡣ࡫ࡱࠦট"),l1lll1l1 (u"ࠢ࡮ࡱࡸࡲࡹ࠴ࡤࡢࡸࡩࡷࠧঠ"))
        os.system(l1lll1l1 (u"ࠣࡥ࡫ࡱࡴࡪࠠ࠵࠹࠸࠹ࠥࠫࡳࠣড") %l1ll1l)
    def l1lllll11l(self):
        logger.info(l1lll1l1 (u"ࠤࡶࡸࡦࡸࡴࠡࡥࡵࡩࡦࡺࡥࠡ࡯ࡲࡹࡳࡺࡦࡴ࠴ࠣࡷࡪࡩࡲࡦࡶࠣࡪ࡮ࡲࡥࠣঢ"))
        l11l=os.path.join(self.l1111l1,self.l1lll11lll)
        l1llll1111 = pwd.getpwnam(self.user).pw_uid
        l1lll1ll1l = grp.getgrnam(self.user).gr_gid
        if not os.path.exists(l11l):
            os.makedirs(l11l)
            os.system(l1lll1l1 (u"ࠥࡧ࡭ࡵࡷ࡯ࠢࠨࡷ࠿ࠫࡳࠡࠧࡶࠦণ") %(self.user,self.user, l11l))
            logger.debug(l1lll1l1 (u"ࠦ࡫ࡵ࡬ࡥࡧࡵࠤࠪࡹࠠࡪࡵࠣࡧࡷ࡫ࡡࡵࡧࠥত") %l11l)
        else:
            logger.debug(l1lll1l1 (u"ࠧ࡬࡯࡭ࡦࡨࡶࠥࠫࡳࠡࡹࡤࡷࠥ࡬࡯ࡶࡰࡧࠦথ") %l11l)
        l1ll1l=os.path.join(l11l, self.l1lll1llll)
        print(l1ll1l)
        logger.debug(l1lll1l1 (u"ࠨࡣࡳࡧࡤࡸࡪࠦࡦࡪ࡮ࡨࠤ࠲ࠦࠥࡴࠢࠥদ")%l1ll1l)
        with open(l1ll1l, l1lll1l1 (u"ࠢࡸ࠭ࠥধ")) as l1lllll1l1:
            logger.debug(self.l1l1l1 + l1lll1l1 (u"ࠨࠢࠪন")+self.l1lll1lll1+l1lll1l1 (u"ࠩࠣࠦࠬ঩")+self.l1lll1l11l+l1lll1l1 (u"ࠪࠦࠬপ"))
            l1lllll1l1.writelines(self.l1l1l1 + l1lll1l1 (u"ࠫࠥ࠭ফ")+self.l1lll1lll1+l1lll1l1 (u"ࠬࠦࠢࠨব")+self.l1lll1l11l+l1lll1l1 (u"࠭ࠢࠨভ"))
        os.chmod(l1ll1l, 0o600)
        os.chown(l1ll1l, l1llll1111, l1lll1ll1l)
    def l1llllll11(self, l1llll11ll=l1lll1l1 (u"ࠧࡥࡣࡹࡪࡸ࠸ࠧম")):
        logger.debug(l1lll1l1 (u"ࠣࡘࡤࡰ࡮ࡪࡡࡵ࡫ࡲࡲࠥ࡯ࡳࠡࡷࡶࡩࡷࠦࡩ࡯ࠢࡪࡶࡴࡻࡰࠣয"))
        groups = [g.gr_name for g in grp.getgrall() if self.user in g.gr_mem]
        gid = pwd.getpwnam(self.user).pw_gid
        groups.append(grp.getgrgid(gid).gr_name)
        if l1llll11ll in groups:
            logger.info(l1lll1l1 (u"ࠤࡘࡷࡪࡸࠠࠦࡵࠣ࡭ࡸࠦࡩ࡯ࠢࡪࡶࡴࡻࡰࠡࠧࡶࠦর") %(self.user,l1llll11ll))
        else:
            logger.warning(l1lll1l1 (u"࡙ࠥࡸ࡫ࡲࠡࠧࡶࠤࡳࡵࡴࠡ࡫ࡱࠤ࡬ࡸ࡯ࡶࡲࠣࠩࡸࠨ঱") %(self.user,l1llll11ll))
            l1ll1=l1lll1l1 (u"ࠫࡺࡹࡥࡳ࡯ࡲࡨࠥ࠳ࡡࠡ࠯ࡊࠤࠪࡹࠠࠦࡵࠪল") %(l1llll11ll,self.user)
            logger.debug(l1lll1l1 (u"ࠧࡩ࡯࡮࡯ࡤࡲࡩࠦࡦࡰࡴࠣࡥࡩࡪࠠࡶࡵࡨࡶࠥࠫࡳࠣ঳") %l1ll1)
            os.system(l1ll1)
            logger.debug(l1lll1l1 (u"ࠨࡡࡥࡦࡨࡨࠥࡹࡵࡤࡧࡶࡷ࡫ࡻ࡬࡭ࠤ঴"))
    def l11111111(self):
        logger.debug(l1lll1l1 (u"ࠢࡗࡣ࡯࡭ࡩࡧࡴࡪࡱࡱࠤ࡫࡯࡬ࡦࠢ࠲ࡩࡹࡩ࠯ࡧࡵࡷࡥࡧࠦ࡯࡯ࠢ࡬ࡷࠥ࡮ࡡࡷࡧࠣࡱࡴࡻ࡮ࡵ࡫ࡱࠤࡷ࡫ࡳࡰࡷࡵࡧࡪࠦࠢ঵"))
        l1lll1l111=l1llll111l()
        l1lll1l111.add(self.l1l1l1, self.l11l, l1lllll111=l1lll1l1 (u"ࠣࡦࡤࡺ࡫ࡹࠢশ"),options=l1lll1l1 (u"ࠤࡸࡷࡪࡸࠬࡳࡹ࠯ࡲࡴࡧࡵࡵࡱࠥষ") )
if __name__==l1lll1l1 (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧস"):
    try:
        l1llll1l1l = urllib.parse.unquote(sys.argv[1])
        if l1llll1l1l:
            l1lllllll1=l1lll11l1l(l1llll1l1l)
        else:
            raise (l1lll1l1 (u"ࠦࡪࡾࡥࡤࡷࡷࡩࠥࡺࡨࡪࡵࠣࡪ࡮ࡲࡥࠡࡴࡨࡵࡺ࡯ࡲࡦࠢࡷࡩࡲࡶࠠࡧ࡫࡯ࡩࠥࡽࡩࡵࡪࠣࡴࡦࡸࡡ࡮ࡵࠣࡱࡴࡻ࡮ࡵ࡫ࡱ࡫ࠧহ"))
    except Exception as e:
        logger.error(l1lll1l1 (u"ࠧࡋࡲࡳࡱࡵ࠾ࠧ঺")+e)
        raise