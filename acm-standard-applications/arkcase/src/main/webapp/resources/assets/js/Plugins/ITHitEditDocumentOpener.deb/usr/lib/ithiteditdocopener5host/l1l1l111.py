#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll = sys.version_info [0] == 2
l1111l = 2048
l1l1l = 7
def l11ll (l1l1):
    global l11l1l
    ll = ord (l1l1 [-1])
    l1l1l1 = l1l1 [:-1]
    l11l = ll % len (l1l1l1)
    l11l11 = l1l1l1 [:l11l] + l1l1l1 [l11l:]
    if l1ll:
        l111l1 = l1lll1 () .join ([unichr (ord (char) - l1111l - (l111l + ll) % l1l1l) for l111l, char in enumerate (l11l11)])
    else:
        l111l1 = str () .join ([chr (ord (char) - l1111l - (l111l + ll) % l1l1l) for l111l, char in enumerate (l11l11)])
    return eval (l111l1)
l1l1l11l = [l11ll (u"ࠦࡲࡹ࠭ࡸࡱࡵࡨࠧࢅ"), l11ll (u"ࠧࡳࡳ࠮ࡲࡲࡻࡪࡸࡰࡰ࡫ࡱࡸࠧࢆ"), l11ll (u"ࠨ࡭ࡴ࠯ࡨࡼࡨ࡫࡬ࠣࢇ"), l11ll (u"ࠢ࡮ࡵ࠰ࡺ࡮ࡹࡩࡰࠤ࢈"), l11ll (u"ࠣ࡯ࡶ࠱ࡦࡩࡣࡦࡵࡶࠦࢉ"), l11ll (u"ࠤࡰࡷ࠲ࡶࡲࡰ࡬ࡨࡧࡹࠨࢊ"), l11ll (u"ࠥࡱࡸ࠳ࡰࡶࡤ࡯࡭ࡸ࡮ࡥࡳࠤࢋ"),
                      l11ll (u"ࠦࡲࡹ࠭ࡴࡲࡧࠦࢌ"), l11ll (u"ࠧࡳࡳ࠮࡫ࡱࡪࡴࡶࡡࡵࡪࠥࢍ")]