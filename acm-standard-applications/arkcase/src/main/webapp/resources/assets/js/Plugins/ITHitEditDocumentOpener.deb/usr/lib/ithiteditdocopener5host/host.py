#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll = sys.version_info [0] == 2
l1111l = 2048
l1l1l = 7
def l11ll (l1l1):
    global l11l1l
    ll = ord (l1l1 [-1])
    l1l1l1 = l1l1 [:-1]
    l11l = ll % len (l1l1l1)
    l11l11 = l1l1l1 [:l11l] + l1l1l1 [l11l:]
    if l1ll:
        l111l1 = l1lll1 () .join ([unichr (ord (char) - l1111l - (l111l + ll) % l1l1l) for l111l, char in enumerate (l11l11)])
    else:
        l111l1 = str () .join ([chr (ord (char) - l1111l - (l111l + ll) % l1l1l) for l111l, char in enumerate (l11l11)])
    return eval (l111l1)
import json
import struct
from l1111 import *
l1l1l1ll = sys.version_info[0] == 2
l1ll11l1 = l11ll (u"ࠣࡋࡗࠤࡍ࡯ࡴࠡࡇࡧ࡭ࡹࠦࡄࡰࡥࠣࡓࡵ࡫࡮ࡦࡴࠥࡃ")
l1ll1111 = l11ll (u"ࠤࡌࡘࠥࡎࡩࡵࠢࡈࡨ࡮ࡺࠠࡅࡱࡦࠤࡔࡶࡥ࡯ࡧࡵࠤ࠺ࠦࡈࡰࡵࡷࠦࡄ")
VERSION = l11ll (u"ࠥ࠹࠳࠸࠰࠯࠷࠹࠹࠺࠴࠰ࠣࡅ")
l1l1ll11 = l11ll (u"ࠦࡎ࡚ࠠࡉ࡫ࡷ࠰ࠥࡒࡴࡥࠤࡆ")
l1lll1ll = l1ll1111.replace(l11ll (u"ࠧࠦࠢࡇ"), l11ll (u"ࠨ࡟ࠣࡈ")) + l11ll (u"ࠢ࠯࡮ࡲ࡫ࠧࡉ")
l1ll1ll1 = {}
if platform.system() == l11ll (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࡊ"):
    if hasattr(sys, l11ll (u"ࠩࡩࡶࡴࢀࡥ࡯ࠩࡋ")):
        l1l111l = sys.argv[0]
        try:
            l1ll1ll1 = l111l1l(l1l111l)
            l1ll1111 = l1ll1ll1[l11ll (u"ࠪࡔࡷࡵࡤࡶࡥࡷࡒࡦࡳࡥࠨࡌ")]
            VERSION = l1ll1ll1[l11ll (u"ࠦࡋ࡯࡬ࡦࡘࡨࡶࡸ࡯࡯࡯ࠤࡍ")]
            l1l1ll11 = l1ll1ll1[l11ll (u"ࠧࡉ࡯࡮ࡲࡤࡲࡾࡔࡡ࡮ࡧࠥࡎ")]
        except:
            pass
    l1lll1ll = l1ll1111.replace(l11ll (u"ࠨࠠࠣࡏ"), l11ll (u"ࠢࡠࠤࡐ")) + l11ll (u"ࠣ࠰࡯ࡳ࡬ࠨࡑ")
    l1l1llll = os.path.join(os.environ.get(l11ll (u"ࠩࡗࡉࡒࡖࠧࡒ")), l1lll1ll)
elif platform.system() == l11ll (u"ࠥࡐ࡮ࡴࡵࡹࠤࡓ"):
    l1ll1l1l = os.path.join(os.environ.get(l11ll (u"ࠫࡍࡕࡍࡆࠩࡔ")), l11ll (u"ࠧ࠴ࠥࡴࠤࡕ") % l1l1ll11.split(l11ll (u"ࠨࠬࠣࡖ"))[0].replace(l11ll (u"ࠢࠡࠤࡗ"), l11ll (u"ࠣࡡࠥࡘ")).lower())
    l1ll1lll = l11ll1l(l1ll1l1l + l11ll (u"ࠤ࠲࡙ࠦ"))
    l1l1llll = os.path.join(l1ll1lll, l1lll1ll)
elif platform.system() == l11ll (u"ࠥࡈࡦࡸࡷࡪࡰ࡚ࠥ"):
    l1ll1l1l = os.path.join(os.environ.get(l11ll (u"ࠫࡍࡕࡍࡆ࡛ࠩ")), l11ll (u"ࠧ࠴ࠥࡴࠤ࡜") % l1l1ll11.split(l11ll (u"ࠨࠬࠣ࡝"))[0].replace(l11ll (u"ࠢࠡࠤ࡞"), l11ll (u"ࠣࡡࠥ࡟")).lower())
    l1ll1lll = l11ll1l(l1ll1l1l + l11ll (u"ࠤ࠲ࠦࡠ"))
    l1l1llll = os.path.join(l1ll1lll, l1lll1ll)
else:
    l1l1llll = os.path.join(l1lll1ll)
logger = logging.getLogger(l11ll (u"ࠥࡲࡦࡺࡩࡷࡧࡢ࡬ࡴࡹࡴࠣࡡ"))
l1ll11l(logger, l1l1llll)
logger.info(l11ll (u"ࠦࡕࡸ࡯ࡥࡷࡦࡸࠥࡏ࡮ࡧࡱ࠽ࠦࡢ"))
logger.info(l11ll (u"ࠧࡢࡴࡂࡲࡳࠤࡓࡧ࡭ࡦ࠼ࠣࠩࡸࠨࡣ") % l1ll1111)
logger.info(l11ll (u"ࠨ࡜ࡵࡘࡨࡶࡸ࡯࡯࡯࠼ࠣࠩࡸࠨࡤ") % VERSION)
logger.info(l11ll (u"ࠢ࡝ࡶࡆࡳࡲࡶࡡ࡯ࡻࠣࡒࡦࡳࡥ࠻ࠢࠨࡷࠧࡥ") % l1l1ll11)
logger.info(l11ll (u"ࠣ࡞ࡷࡓࡵ࡫࡮ࡦࡴࠣࡑࡦࡹ࡫࠻ࠢࠨࡷࠧࡦ") % l1ll11l1)
l1llll = get_major_version(VERSION)
l1l11l = l11l1l1(l1llll, l1ll11l1)
logger.info(l11ll (u"ࠤ࡟ࡸࡒࡧࡪࡰࡴ࡚ࠣࡪࡸࡳࡪࡱࡱ࠾ࠥࠫࡳࠣࡧ") % l1llll)
logger.info(l11ll (u"ࠥࡠࡹࡖࡲࡰࡶࡲࡧࡴࡲࠠࡏࡣࡰࡩࡸࡀࠠࠦࡵࠥࡨ") % l1l11l)
logger.info(l11ll (u"ࠫࡡࡺࡏࡔ࠼ࠣࠩࡸ࠭ࡩ") % platform.platform())
logger.info(l11ll (u"ࠬࡢࡴࡑࡻࡷ࡬ࡴࡴ࠺ࠡࠧࡶࠫࡪ") % sys.version)
def l1lll11l():
    if l1l1l1ll:
        return sys.stdin
    else:
        return sys.stdin.buffer
def l1ll111l():
    if l1l1l1ll:
        return sys.stdout
    else:
        return sys.stdout.buffer
def l1l1lll1():
    l1l1ll1l = l1lll11l().read(4)
    while len(l1l1ll1l) == 4:
        l1llll11 = struct.unpack(l11ll (u"ࠨࡀࡊࠤ࡫"), l1l1ll1l)[0]
        request = l1lll11l().read(l1llll11).decode()
        logger.info(l11ll (u"ࠢࡈࡱࡷࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡀࡻ࠱ࡿࠥ࡬").format(request))
        response = l1ll1l11(request)
        l1lll1l1(response)
        logger.info(l11ll (u"ࠣࡕࡨࡲࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠼ࡾ࠴ࢂࠨ࡭").format(response))
        l1l1ll1l = l1lll11l().read(4)
    logger.info(l11ll (u"ࠩࡈࡼ࡮ࡺࡩ࡯ࡩࠤࠫ࡮"))
def l1lll1l1(message):
    message = json.dumps(message).encode()
    l1ll11ll = struct.pack(l11ll (u"ࠥࡄࡎࠨ࡯"), len(message))
    l1ll111l().write(l1ll11ll)
    l1ll111l().write(message)
    l1ll111l().flush()
def l1ll1l11(request):
    if request:
        l1llll1l = json.loads(request)
    try:
        return {
            l11ll (u"ࠫ࡬࡫ࡴࡠࡲࡵࡳࡹࡵࡣࡰ࡮ࡶࠫࡰ"): l11,
            l11ll (u"ࠬࡵࡰࡦࡰࡢࡴࡷࡵࡴࡰࡥࡲࡰࠬࡱ"): l1lll11,
            l11ll (u"࠭ࡩ࡯࡫ࡷࡣࡦࡴ࡯࡯ࠩࡲ"): l1l1ll1
        }[l1llll1l[l11ll (u"ࠢࡢࡥࡷࠦࡳ")]](l1llll1l)
    except Exception as e:
        logger.error(l11ll (u"ࠨࡵࡺ࡭ࡹࡩࡨࡠࡣࡦࡸ࡮ࡵ࡮ࡴࠢࡨࡶࡷࡵࡲ࠻ࠢࠪࡴ") + str(e))
        return l11()
def l11(l1llll1l=None):
    l1lllll1(l1llll1l)
    l1lll111 = {l11ll (u"ࠩࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡘࡩࡨࡦ࡯ࡨࡷࠬࡵ"): l1l()}
    l1lll111[l11ll (u"ࠥࡴࡷࡵࡴࡰࡥࡲࡰࡸࠨࡶ")] = l1llllll(l1l11l)
    return l1lll111
def l1lll11(l1llll1l):
    url = l1llll1l[l11ll (u"ࠦࡺࡸ࡬ࠣࡷ")]
    l11l1 = url.split(l11ll (u"ࠬࡀࠧࡸ"))[0]
    return {l11ll (u"࠭ࡣ࡮ࡦࡢࡶࡪࡹࡵ࡭ࡶࠪࡹ"): l11ll11(l11l1, url)}
def l1l1ll1(l1llll1l):
    try:
        l11l1 = l1l1l11(l1l11l)
        url = l11ll (u"ࡲࠨࠧࡶ࠾ࡦࡩࡴ࠾ࠧࡶ࠿ࡎࡺࡥ࡮ࡗࡵࡰࡂࡔࡏࡏࡇ࠾ࠩࡸ࠭ࡺ") % (l11l1, l1llll1l[l11ll (u"ࠨࡣࡦࡸࠬࡻ")], l1llll1l[l11ll (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩࡼ")])
        logger.debug(l11ll (u"ࠥࡶࡺࡴ࡟ࡱࡴࡲࡸࡴࡩ࡯࡭ࠪࠪࠩࡸ࠭ࠬࠡࠩࠨࡷࠬ࠯ࠢࡽ") % (l11l1, url))
        return {l11ll (u"ࠫࡨࡳࡤࡠࡴࡨࡷࡺࡲࡴࠨࡾ"): l11ll11(l11l1, url)}
    except Exception as e:
        logger.error(str(e))
        return {l11ll (u"ࠬࡩ࡭ࡥࡡࡵࡩࡸࡻ࡬ࡵࠩࡿ"): str(e)}
def l1lllll1(l1llll1l):
    l1l1l1l1 = l11ll (u"࠭ࠧࢀ")
    if l1llll1l:
        for name in l1llll1l:
            if name in [l11ll (u"ࠧࡣࡡࡱࡥࡲ࡫ࠧࢁ"),l11ll (u"ࠨࡤࡢࡺࡪࡸࠧࢂ")]:
                l1l1l1l1 += l11ll (u"ࠩࠨࡷࠥ࠭ࢃ") % l1llll1l[name]
    if l1l1l1l1: logger.info(l1l1l1l1[:-1])
def main():
    try:
        l1l1111()
        l1l1lll1()
    except Exception as ex:
        logger.exception(ex)
        raise
    sys.exit(0)
if __name__ == l11ll (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧࢄ"):
    main()