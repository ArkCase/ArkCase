#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1lll = sys.version_info [0] == 2
l1lll1ll = 2048
l111l = 7
def l1lll1l1 (l11l1l1):
    global l11ll11
    l1l1ll1 = ord (l11l1l1 [-1])
    l1l11l1 = l11l1l1 [:-1]
    l11ll = l1l1ll1 % len (l1l11l1)
    l11 = l1l11l1 [:l11ll] + l1l11l1 [l11ll:]
    if l1l1lll:
        l1ll1ll = l1ll1l11 () .join ([unichr (ord (char) - l1lll1ll - (l1lll + l1l1ll1) % l111l) for l1lll, char in enumerate (l11)])
    else:
        l1ll1ll = str () .join ([chr (ord (char) - l1lll1ll - (l1lll + l1l1ll1) % l111l) for l1lll, char in enumerate (l11)])
    return eval (l1ll1ll)
import logging
import os
import re
from l1l1 import l1llll111
logger = logging.getLogger(l1lll1l1 (u"ࠥࡨࡴࡩࡵ࡮ࡧࡱࡸࡤࡵࡰࡦࡰࡨࡶࠧॲ"))
def l11ll1l(path):
    dirname=os.path.dirname(path)
    if dirname[0]== l1lll1l1 (u"ࠦࢃࠨॳ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l1ll1l1():
    try:
        out = os.popen(l1lll1l1 (u"ࠧ࠵ࡵࡴࡴ࠲ࡷࡧ࡯࡮࠰࡯ࡲࡹࡳࡺ࠮ࡥࡣࡹࡪࡸࠦ࠭ࡗࠤॴ")).read()
        if out:
            result = re.findall(l1lll1l1 (u"ࡸࠢࡥࡣࡹࡪࡸ࠴ࠫࡀࠪ࡞ࡠࡩࢂ࡜࠯࡟࠮ࡃ࠮ࡢࡳࠣॵ"), out)
            if result:
                result = l1lll1l1 (u"ࠢࠣॶ").join(result)
                logger.info(l1lll1l1 (u"ࠣࡘࡨࡶࡸ࡯࡯࡯ࠢࡲࡪࠥࡪࡡࡷࡨࡶࠤࡺࡹࡥ࠻࡞ࡱࡠࡹࠦࠥࡴࠤॷ") % l1lll1l1 (u"ࠤࠥॸ").join(result))
                return result
        else:
            raise Exception(l1lll1l1 (u"ࠥࡨࡦࡼࡦࡴ࠴ࠣࡲࡴࡺࠠࡧࡱࡸࡲࡩࠨॹ"))
    except:
        logger.exception(l1lll1l1 (u"ࠦࡊࡸࡲࡰࡴࠣࡻ࡮ࡺࡨࠡࡦࡨࡸࡪࡩࡴࠡࡦࡤࡺ࡫ࡹ࠲ࠡࡸࡨࡶࡸ࡯࡯࡯࠼ࠥॺ"))
        raise l1llll111(l1lll1l1 (u"ࠧࡖࡲࡰࡤ࡯ࡩࡲࠦࡷࡪࡶ࡫ࠤࡩ࡫ࡴࡦࡥࡷࠤࡩࡧࡶࡧࡵ࠵ࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠦࡍࡢࡻࠣࡦࡪࠦࡩࡵࠢ࡬ࡷࠥࡴ࡯ࡵࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨ࠳ࠨॻ"))
if __name__ == l1lll1l1 (u"ࠨ࡟ࡠ࡯ࡤ࡭ࡳࡥ࡟ࠣॼ"):
    l11ll1l(l1lll1l1 (u"ࠢࡿ࠱࠱࡭ࡹ࡮ࡩࡵ࠱ࡧࡨࡩ࠵ࡦࡧࡨࡩ࠳࡫࡬ࡦ࠯ࡶࡻࡸࠧॽ"))