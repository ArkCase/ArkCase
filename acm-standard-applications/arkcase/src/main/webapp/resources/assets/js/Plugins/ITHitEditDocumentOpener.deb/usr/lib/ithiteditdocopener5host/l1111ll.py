#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll = sys.version_info [0] == 2
l1111l = 2048
l1l1l = 7
def l11ll (l1l1):
    global l11l1l
    ll = ord (l1l1 [-1])
    l1l1l1 = l1l1 [:-1]
    l11l = ll % len (l1l1l1)
    l11l11 = l1l1l1 [:l11l] + l1l1l1 [l11l:]
    if l1ll:
        l111l1 = l1lll1 () .join ([unichr (ord (char) - l1111l - (l111l + ll) % l1l1l) for l111l, char in enumerate (l11l11)])
    else:
        l111l1 = str () .join ([chr (ord (char) - l1111l - (l111l + ll) % l1l1l) for l111l, char in enumerate (l11l11)])
    return eval (l111l1)
import _winreg
import subprocess, threading
from l1111 import l1l1ll
from l1l1l111 import l1l1l11l
def l11l11l():
    l1l11l1l = [l11ll (u"ࠨࡅࡹࡥࡨࡰࠧࢎ"), l11ll (u"ࠢࡘࡱࡵࡨࠧ࢏"), l11ll (u"ࠣࡒࡲࡻࡪࡸࡐࡰ࡫ࡱࡸࠧ࢐"), l11ll (u"ࠤࡒࡹࡹࡲ࡯ࡰ࡭ࠥ࢑")]
    for part in l1l11l1l:
        try:
            l11lll1l = l11ll (u"ࠥࡿ࠵ࢃ࠮ࡂࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࡡࡢࡃࡶࡴ࡙ࡩࡷࠨ࢒").format(part)
            l1l11lll = _winreg.l11lllll(_winreg.l11ll11l, l11lll1l)
        except l11l11l1:
            continue
        value = _winreg.l1l11ll1(l1l11lll, l11ll (u"ࠦࠧ࢓"))
        return value.split(l11ll (u"ࠧ࠴ࠢ࢔"))[-1]
    return None
def l11111l():
    l11l11ll = []
    for name in l1l1l11l:
        try:
            l11lll1l = l11ll (u"ࠨࡻ࠱ࡿ࡟ࡠࡸ࡮ࡥ࡭࡮࡟ࡠࡴࡶࡥ࡯࡞࡟ࡧࡴࡳ࡭ࡢࡰࡧࠦ࢕").format(name)
            l1l111ll = _winreg.l11lllll(_winreg.l11ll11l, l11lll1l)
            if _winreg.l1l11ll1(l1l111ll, l11ll (u"ࠢࠣ࢖")):
                l11l11ll.append(name)
        except l11l11l1:
            continue
    return l11l11ll
def l1l1lll(l1llll, l1):
    import re
    l1lll = []
    l11lll11 = _winreg.l11lllll(_winreg.l11ll11l, l11ll (u"ࠣࡃࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࡹࠢࢗ"))
    for i in range(0, _winreg.l11ll1ll(l11lll11)[0]):
        try:
            l11l1l1l = _winreg.l11llll1(l11lll11, i)
            if l11l1l1l.startswith(l1):
                l11ll1l1 = _winreg.l11l1lll(l11lll11, l11l1l1l)
                value, l1l11l11 = _winreg.l1l11111(l11ll1l1, l11ll (u"ࠩࡉࡶ࡮࡫࡮ࡥ࡮ࡼࡅࡵࡶࡎࡢ࡯ࡨࠫ࢘"))
                m = re.search(l11ll (u"ࠪࡺ࠭࠮࡛࡝ࡦࡠࡿ࠶࠲ࡽࠪ࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡡ࠴࡛࡝ࡦࡠࡿ࠶࠲ࡽ࡜࡞࠱࡟ࡡࡪ࡝ࡼ࠳࠯ࢁࡢࡅࠩࠨ࢙"), value)
                if m:
                    l11l1l11 = {l11ll (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࢚ࠬ"): m.group(1)}
                    l11l1ll1 = m.group(2)
                    if l1llll == l11l1ll1:
                        m = re.search(l1.replace(l11ll (u"ࠬ࠴࢛ࠧ"), l11ll (u"࠭࡜࡝࠰ࠪ࢜")) + l11ll (u"ࠧࠩ࡝࡟ࡻࡢ࠰ࠩ࡝࠰ࡨࡼࡪ࠭࢝"), l11l1l1l)
                        l11l1l11[l11ll (u"ࠨࡲࡵࡳࡹࡵࡣࡰ࡮ࠪ࢞")] = m.group(1)
                        l1lll.append(l11l1l11)
                else:
                    raise ValueError(l11ll (u"ࠤࡆࡥࡳ࠭ࡴࠡࡩࡨࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡦࡳࡱࡰ࠾ࠥࠫࡳࠡࠤ࢟") % value)
        except l11l11l1 as ex:
            continue
    return l1lll
def l11l111l(l11l1):
    try:
        l1l1111l = l11ll (u"ࠥࡿ࠵ࢃ࡜࡝ࡵ࡫ࡩࡱࡲ࡜࡝ࡱࡳࡩࡳࡢ࡜ࡤࡱࡰࡱࡦࡴࡤࠣࢠ").format(l11l1)
        l11l1111 = _winreg.l11lllll(_winreg.l11ll11l, l1l1111l)
        value, l1l11l11 = _winreg.l1l11111(l11l1111, l11ll (u"ࠫࠬࢡ"))
        if value:
            return value.split(l11ll (u"ࠬࠨࠧࢢ"))[1]
    except l11l11l1:
        pass
    return l11ll (u"࠭ࠧࢣ")
def l1lll11(l11l1, url):
    threading.Thread(target=_1l111l1,args=(l11l1, url)).start()
    return l11ll (u"ࠢࡔࡷࡦࡧࡪࡹࡳࠣࢤ")
def _1l111l1(l11l1, url):
    logger = l1l1ll()
    l11ll111 = l11l111l(l11l1)
    logger.debug(l11ll (u"ࡳࠩࠥࠩࡸࠨࠠࠦࡵࠪࢥ") % (l11ll111, url))
    retcode = subprocess.Popen(l11ll (u"ࡴࠪࠦࠪࡹࠢࠡࠧࡶࠫࢦ") % (l11ll111, url), shell=False, stdin=None, stdout=None, stderr=None,
                               close_fds=True, creationflags=0x00000008)
    retcode = retcode.wait()
    if retcode < 0:
        logger.info(l11ll (u"ࠥࡓࡵ࡫࡮ࡦࡴࠣࡻࡦࡹࠠࡵࡧࡵࡱ࡮ࡴࡡࡵࡧࡧࠤࡧࡿࠠࡴ࡫ࡪࡲࡦࡲࠬࠡࠧࡶࠦࢧ") % retcode)
    else:
        logger.info(l11ll (u"ࠦࡔࡶࡥ࡯ࡧࡵࠤࡷ࡫ࡴࡶࡴࡱࡩࡩ࠲ࠠࠦࡵࠥࢨ") % retcode)