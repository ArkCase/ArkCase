#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll = sys.version_info [0] == 2
l1111l = 2048
l1l1l = 7
def l11ll (l1l1):
    global l11l1l
    ll = ord (l1l1 [-1])
    l1l1l1 = l1l1 [:-1]
    l11l = ll % len (l1l1l1)
    l11l11 = l1l1l1 [:l11l] + l1l1l1 [l11l:]
    if l1ll:
        l111l1 = l1lll1 () .join ([unichr (ord (char) - l1111l - (l111l + ll) % l1l1l) for l111l, char in enumerate (l11l11)])
    else:
        l111l1 = str () .join ([chr (ord (char) - l1111l - (l111l + ll) % l1l1l) for l111l, char in enumerate (l11l11)])
    return eval (l111l1)
import os
import re
import subprocess
import l1111
from l1111 import l1l1ll
def l1l():
    return []
def l11(l1llll, l1):
    logger = l1l1ll()
    l1lll = []
    l1ll1 = [l11ll (u"ࠦࡩࡶ࡫ࡨࠢ࠰ࡰࠥࢂࠠࡨࡴࡨࡴࠥࡵࡰࡦࡰࡨࡶࠧࠀ"),
            l11ll (u"ࠬࡸࡰ࡮ࠢ࠰ࡵࡦࠦ࠭࠮࡮ࡤࡷࡹࠦࡼࠡࡩࡵࡩࡵࠦࡏࡱࡧࡱࡩࡷ࠭ࠁ")
            ]
    for cmd in l1ll1:
        try:
            output = os.popen(cmd).read()
            l1l111 = 0
            l1l11l = {}
            if l1l111 == 0:
                l111 = re.compile(l11ll (u"ࡸࠧࠩ࡞ࡧ࠭࠭ࡢ࠮࡝ࡦ࠮࠭ࢀ࠸ࠬ࠴ࡿࠪࠂ"))
                l1ll1l = re.compile(l11ll (u"ࡲࠨ࡝ࡤ࠱ࡿࡣࠨ࡝ࡦ࠮࠭࠭ࡅࠡ࡝ࡹࠬࠫࠃ"))
                for line in output.splitlines():
                    l1l11 = re.search(l111, line)
                    l11lll = l1l11.group(1)
                    if l1llll == l11lll:
                        l11ll1 = re.search(l1ll1l, line)
                        if l11ll1:
                            l11l1 = l11ll (u"ࠨࡦࡤࡺࠬࠄ")+l11ll1.group(1)
                            version = l1l11.group(0)
                            if not l11l1 in l1l11l:
                                l1l11l[l11l1] = version
                            elif l1111.l111ll(version, l1l11l[l11l1]) > 0:
                                l1l11l[l11l1] = version
            for l11l1 in l1l11l:
                l1lll.append({l11ll (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࠅ"): l1l11l[l11l1], l11ll (u"ࠪࡴࡷࡵࡴࡰࡥࡲࡰࠬࠆ"): l11l1})
        except Exception as e:
            logger.error(str(e))
    return l1lll