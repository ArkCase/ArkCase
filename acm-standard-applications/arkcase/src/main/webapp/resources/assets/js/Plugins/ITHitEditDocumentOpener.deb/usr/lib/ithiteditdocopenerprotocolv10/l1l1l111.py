#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1lll = sys.version_info [0] == 2
l1lll1ll = 2048
l111l = 7
def l1lll1l1 (l11l1l1):
    global l11ll11
    l1l1ll1 = ord (l11l1l1 [-1])
    l1l11l1 = l11l1l1 [:-1]
    l11ll = l1l1ll1 % len (l1l11l1)
    l11 = l1l11l1 [:l11ll] + l1l11l1 [l11ll:]
    if l1l1lll:
        l1ll1ll = l1ll1l11 () .join ([unichr (ord (char) - l1lll1ll - (l1lll + l1l1ll1) % l111l) for l1lll, char in enumerate (l11)])
    else:
        l1ll1ll = str () .join ([chr (ord (char) - l1lll1ll - (l1lll + l1l1ll1) % l111l) for l1lll, char in enumerate (l11)])
    return eval (l1ll1ll)
import os, time
import logging
from logging.handlers import SysLogHandler
import platform
import re
from l1 import l11ll1l
from configobj import ConfigObj
l1l111l1 = l1lll1l1 (u"ࠥࡨࡦࡼ࠱࠱ࠤࡡ")
l1l11lll = l1lll1l1 (u"ࠦࡎ࡚ࠠࡉ࡫ࡷࠤࡊࡪࡩࡵࠢࡇࡳࡨࠦࡏࡱࡧࡱࡩࡷࠦࠨࡑࡴࡲࡸࡴࡩ࡯࡭ࠢࡹ࠵࠵࠯ࠠࡅࡃ࡙࠵࠵ࠦࡶ࠶࠰࠵࠴࠳࠻࠶࠶࠷࠱࠴ࠧࡢ")
l1l1l1l1 = l1lll1l1 (u"ࠧࡏࡔࠡࡊ࡬ࡸࠧࡣ")
VERSION = l1lll1l1 (u"ࠨ࠵࠯࠴࠳࠲࠺࠼࠵࠶࠰࠳ࠦࡤ")
l1l1111l=os.path.join(os.environ.get(l1lll1l1 (u"ࠧࡉࡑࡐࡉࠬࡥ")),l1lll1l1 (u"ࠣ࠰ࠨࡷࠧࡦ") %l1l1l1l1.replace(l1lll1l1 (u"ࠤࠣࠦࡧ"), l1lll1l1 (u"ࠥࡣࠧࡨ")).lower())
l1ll1111=os.environ.get(l1lll1l1 (u"ࠫࡎ࡚ࡈࡊࡖࡢࡐࡔࡍࡌࡆࡘࡈࡐࠬࡩ"), l1lll1l1 (u"ࠧࡊࡅࡃࡗࡊࠦࡪ"))
l1l11111=l1l11lll.replace(l1lll1l1 (u"ࠨࠠࠣ࡫"), l1lll1l1 (u"ࠢࡠࠤ࡬"))+l1lll1l1 (u"ࠣ࠰࡯ࡳ࡬ࠨ࡭")
if platform.system() == l1lll1l1 (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࡮"):
    l11llll1=os.path.join(os.environ.get(l1lll1l1 (u"ࠪࡘࡊࡓࡐࠨ࡯")),l1l11111)
elif platform.system() == l1lll1l1 (u"ࠦࡑ࡯࡮ࡶࡺࠥࡰ"):
    l11ll11l=l11ll1l(l1l1111l+l1lll1l1 (u"ࠧ࠵ࠢࡱ"))
    l11llll1 = os.path.join(l11ll11l, l1l11111)
else:
    l11llll1 = os.path.join( l1l11111)
l1ll1111=l1ll1111.upper()
if l1ll1111 == l1lll1l1 (u"ࠨࡄࡆࡄࡘࡋࠧࡲ"): l11lll1l=logging.DEBUG
elif l1ll1111 == l1lll1l1 (u"ࠢࡊࡐࡉࡓࠧࡳ"): l11lll1l = logging.INFO
elif l1ll1111 == l1lll1l1 (u"࡙ࠣࡄࡖࡓࡏࡎࡈࠤࡴ"): l11lll1l = logging.WARNING
elif l1ll1111 == l1lll1l1 (u"ࠤࡈࡖࡗࡕࡒࠣࡵ"): l11lll1l = logging.ERROR
elif l1ll1111 == l1lll1l1 (u"ࠥࡇࡗࡏࡔࡊࡅࡄࡐࠧࡶ"):  l11lll1l = logging.CRITICAL
elif l1ll1111 == l1lll1l1 (u"ࠦࡓࡕࡔࡔࡇࡗࠦࡷ"): l11lll1l = logging.NOTSET
logger = logging.getLogger(l1lll1l1 (u"ࠧࡪ࡯ࡤࡷࡰࡩࡳࡺ࡟ࡰࡲࡨࡲࡪࡸࠢࡸ"))
logger.setLevel(l11lll1l)
l1l1ll11 = logging.FileHandler(l11llll1, mode=l1lll1l1 (u"ࠨࡷࠬࠤࡹ"))
l1l1ll11.setLevel(l11lll1l)
formatter = logging.Formatter(l1lll1l1 (u"ࠧࠦࠪࡤࡷࡨࡺࡩ࡮ࡧࠬࡷࠥ࠳ࠠࠦࠪࡱࡥࡲ࡫ࠩࡴࠢ࠰ࠤࠪ࠮࡬ࡦࡸࡨࡰࡳࡧ࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩ࡯ࡨࡷࡸࡧࡧࡦࠫࡶࠫࡺ"),l1lll1l1 (u"ࠣࠧࡤ࠰ࠥࠫࡤ࠮ࠧࡥ࠱ࠪ࡟ࠠࠦࡊ࠽ࠩࡒࡀࠥࡔࠢࡊࡑ࡙ࠨࡻ"))
formatter.converter = time.gmtime
l1l1ll11.setFormatter(formatter)
ch = logging.StreamHandler()
ch.setLevel(l11lll1l)
l1l111ll = SysLogHandler(address=l1lll1l1 (u"ࠩ࠲ࡨࡪࡼ࠯࡭ࡱࡪࠫࡼ"))
l1l111ll.setFormatter(formatter)
logger.addHandler(l1l1ll11)
logger.addHandler(ch)
logger.addHandler(l1l111ll)
class Settings():
    l1l1lll1 = l1lll1l1 (u"ࠪࡘࡷࡻࡥࠨࡽ")
    l1l1l1ll = l1lll1l1 (u"ࠫࡓࡵ࡮ࡦࠩࡾ")
    l11lllll = l1lll1l1 (u"ࠬ࠸࠴ࠨࡿ")
    def __init__(self, l1l11lll):
        self.l1l11l11 = self._1l1l11l(l1l11lll)
        self._11lll11()
    def _1l1l11l(self, l1l11lll):
        l1ll111l = l1l11lll.split(l1lll1l1 (u"ࠨࠠࠣࢀ"))
        l1ll111l = l1lll1l1 (u"ࠢࠡࠤࢁ").join(l1ll111l)
        if platform.system() == l1lll1l1 (u"ࠣࡎ࡬ࡲࡺࡾࠢࢂ"):
            l1l11l11 = os.path.join(l1l1111l, l1lll1l1 (u"ࠤࡆࡳࡳ࡬ࡩࡨࠤࢃ"), l1ll111l + l1lll1l1 (u"ࠥ࠲ࡨ࡬ࡧࠣࢄ"))
        return l1l11l11
    def l11ll1ll(self, parent, key, value):
        if self.config.get(parent):
            self.config[parent][key]= value
        else:
            self.config[parent]={}
            self.config[parent][key] = value
        self.config.write()
    def l11ll1l1(self, parent, key):
        result=[]
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                regexp=re.compile(l1lll1l1 (u"ࡶࠧࡢࡼ࡝ࡵࠫ࠲࠰ࡅࠩ࡝ࡵ࡟ࢀࠧࢅ"))
                result=regexp.findall(data)
        return result
    def get_value(self, parent, key):
        result=l1lll1l1 (u"ࠧࠨࢆ")
        if self.config.get(parent):
            data=self.config[parent].get(key)
            if data:
                result = data
        return result
    def l1l11ll1(self, parent):
        result = None
        if self.config.get(parent):
            data = self.config[parent]
            result = data
        return result
    def _11lll11(self):
        if not os.path.exists(os.path.dirname(self.l1l11l11)):
            os.makedirs(os.path.dirname(self.l1l11l11))
        if not os.path.exists(self.l1l11l11):
            self.config = ConfigObj(self.l1l11l11)
            self.config[l1lll1l1 (u"࠭ࡃࡰࡱ࡮࡭ࡪࡹࠧࢇ")] = {}
            self.config[l1lll1l1 (u"ࠧࡄࡱࡲ࡯࡮࡫ࡳࠨ࢈")][l1lll1l1 (u"ࠨࡧࡻࡴ࡮ࡸࡥࡥࡡࡷ࡭ࡲ࡫࡟ࡱ࡮ࡸࡷࡤ࡮࡯ࡶࡴࠪࢉ")] = self.l11lllll
            self.config[l1lll1l1 (u"ࠩࡓࡩࡷࡳࡩࡴࡵ࡬ࡳࡳࡹࠧࢊ")] = {}
            self.config[l1lll1l1 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨࢋ")][l1lll1l1 (u"ࠫࡪࡾࡴࡦࡰࡧࡣࡪࡾࡰࡪࡴࡨࡨࡤࡩ࡯ࡰ࡭࡬ࡩࡸ࠭ࢌ")] = self.l1l1l1ll
            self.config[l1lll1l1 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪࢍ")][l1lll1l1 (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧࢎ")] = self.l1l1lll1
            self.config[l1lll1l1 (u"ࠧࡍࡱࡪ࡭ࡳࡹࠧ࢏")] = {}
            self.config.write()
        else:
            self.config = ConfigObj(self.l1l11l11)
            self.l11lllll = self.get_value(l1lll1l1 (u"ࠨࡅࡲࡳࡰ࡯ࡥࡴࠩ࢐"),l1lll1l1 (u"ࠩࡨࡼࡵ࡯ࡲࡦࡦࡢࡸ࡮ࡳࡥࡠࡲ࡯ࡹࡸࡥࡨࡰࡷࡵࠫ࢑"))
            self.l1l1l1ll = self.get_value(l1lll1l1 (u"ࠪࡔࡪࡸ࡭ࡪࡵࡶ࡭ࡴࡴࡳࠨ࢒"),l1lll1l1 (u"ࠫࡪࡾࡴࡦࡰࡧࡣࡪࡾࡰࡪࡴࡨࡨࡤࡩ࡯ࡰ࡭࡬ࡩࡸ࠭࢓"))
            self.l1l1lll1 = self.get_value(l1lll1l1 (u"ࠬࡖࡥࡳ࡯࡬ࡷࡸ࡯࡯࡯ࡵࠪ࢔"),l1lll1l1 (u"࠭ࡳࡩࡱࡺࡣࡲ࡫ࡳࡴࡣࡪࡩࡤࡧࡳࡠ࡯ࡲࡨࡦࡲࠧ࢕"))
    def _1l1ll1l(self):
        l1l11l1l = l1lll1l1 (u"ࠢࡴࡪࡲࡻࡤࡳࡥࡴࡵࡤ࡫ࡪࡥࡡࡴࡡࡰࡳࡩࡧ࡬࠻ࠢࠨࡷࠥࢂࠠࠣ࢖") % self.l1l1lll1
        l1l11l1l += l1lll1l1 (u"ࠣࡧࡻࡸࡪࡴࡤࡠࡧࡻࡴ࡮ࡸࡥࡥࡡࡦࡳࡴࡱࡩࡦࡵ࠽ࠤࠪࡹࠠࡽࠢࠥࢗ") % self.l1l1l1ll
        l1l11l1l += l1lll1l1 (u"ࠤࡨࡼࡵ࡯ࡲࡦࡦࡢࡸ࡮ࡳࡥࡠࡲ࡯ࡹࡸࡥࡨࡰࡷࡵ࠾ࠥࠫࡳࠣ࢘") % self.l11lllll
        return l1l11l1l
    def __unicode__(self):
        return self._1l1ll1l()
    def __str__(self):
        return self._1l1ll1l()
    def __del__(self):
        self.config.write()
l1l1llll = Settings(l1l11lll)