#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll = sys.version_info [0] == 2
l1111l = 2048
l1l1l = 7
def l11ll (l1l1):
    global l11l1l
    ll = ord (l1l1 [-1])
    l1l1l1 = l1l1 [:-1]
    l11l = ll % len (l1l1l1)
    l11l11 = l1l1l1 [:l11l] + l1l1l1 [l11l:]
    if l1ll:
        l111l1 = l1lll1 () .join ([unichr (ord (char) - l1111l - (l111l + ll) % l1l1l) for l111l, char in enumerate (l11l11)])
    else:
        l111l1 = str () .join ([chr (ord (char) - l1111l - (l111l + ll) % l1l1l) for l111l, char in enumerate (l11l11)])
    return eval (l111l1)
import logging
import os
import platform
import sys
from logging.handlers import RotatingFileHandler
def l111l1l(l1l111l=None):
    if platform.system() == l11ll (u"ࠦ࡜࡯࡮ࡥࡱࡺࡷࠧࠇ"):
        import l111lll
        props = {}
        try:
            prop_names = (l11ll (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡹࠧࠈ"), l11ll (u"࠭ࡉ࡯ࡶࡨࡶࡳࡧ࡬ࡏࡣࡰࡩࠬࠉ"), l11ll (u"ࠧࡑࡴࡲࡨࡺࡩࡴࡏࡣࡰࡩࠬࠊ"),
                          l11ll (u"ࠨࡅࡲࡱࡵࡧ࡮ࡺࡐࡤࡱࡪ࠭ࠋ"), l11ll (u"ࠩࡏࡩ࡬ࡧ࡬ࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠪࠌ"), l11ll (u"ࠪࡔࡷࡵࡤࡶࡥࡷ࡚ࡪࡸࡳࡪࡱࡱࠫࠍ"),
                          l11ll (u"ࠫࡋ࡯࡬ࡦࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ࠎ"), l11ll (u"ࠬࡒࡥࡨࡣ࡯ࡘࡷࡧࡤࡦ࡯ࡤࡶࡰࡹࠧࠏ"), l11ll (u"࠭ࡐࡳ࡫ࡹࡥࡹ࡫ࡂࡶ࡫࡯ࡨࠬࠐ"),
                          l11ll (u"ࠧࡇ࡫࡯ࡩ࡛࡫ࡲࡴ࡫ࡲࡲࠬࠑ"), l11ll (u"ࠨࡑࡵ࡭࡬࡯࡮ࡢ࡮ࡉ࡭ࡱ࡫࡮ࡢ࡯ࡨࠫࠒ"), l11ll (u"ࠩࡖࡴࡪࡩࡩࡢ࡮ࡅࡹ࡮ࡲࡤࠨࠓ"))
            lang, l1ll1l1 = l111lll.l111ll1(l1l111l, l11ll (u"ࠪࡠࡡ࡜ࡡࡳࡈ࡬ࡰࡪࡏ࡮ࡧࡱ࡟ࡠ࡙ࡸࡡ࡯ࡵ࡯ࡥࡹ࡯࡯࡯ࠩࠔ"))[0]
            for l1l11l1 in prop_names:
                l111111 = l11ll (u"ࡹࠬࡢ࡜ࡔࡶࡵ࡭ࡳ࡭ࡆࡪ࡮ࡨࡍࡳ࡬࡯࡝࡞ࠨ࠴࠹࡞ࠥ࠱࠶࡛ࡠࡡࠫࡳࠨࠕ") % (lang, l1ll1l1, l1l11l1)
                props[l1l11l1] = l111lll.l111ll1(l1l111l, l111111)
        except:
            pass
    return props
def l1ll11l(logger, l11111):
    l11l111 = os.environ.get(l11ll (u"ࠬࡏࡔࡉࡋࡗࡣࡑࡕࡇࡍࡇ࡙ࡉࡑ࠭ࠖ"), l11ll (u"ࠨࡄࡆࡄࡘࡋࠧࠗ"))
    l11l111 = l11l111.upper()
    if l11l111 == l11ll (u"ࠢࡅࡇࡅ࡙ࡌࠨ࠘"):
        l11lll1 = logging.DEBUG
    elif l11l111 == l11ll (u"ࠣࡋࡑࡊࡔࠨ࠙"):
        l11lll1 = logging.INFO
    elif l11l111 == l11ll (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉࠥࠚ"):
        l11lll1 = logging.WARNING
    elif l11l111 == l11ll (u"ࠥࡉࡗࡘࡏࡓࠤࠛ"):
        l11lll1 = logging.ERROR
    elif l11l111 == l11ll (u"ࠦࡈࡘࡉࡕࡋࡆࡅࡑࠨࠜ"):
        l11lll1 = logging.CRITICAL
    elif l11l111 == l11ll (u"ࠧࡔࡏࡕࡕࡈࡘࠧࠝ"):
        l11lll1 = logging.NOTSET
    logger.setLevel(l11lll1)
    l1l11ll = RotatingFileHandler(l11111, maxBytes=1024*1024*5, backupCount=3)
    l1l11ll.setLevel(l11lll1)
    formatter = logging.Formatter(l11ll (u"࠭ࠥࠩࡣࡶࡧࡹ࡯࡭ࡦࠫࡶࠤ࠲ࠦࠥࠩࡰࡤࡱࡪ࠯ࡳࠡ࠯ࠣࠩ࠭ࡲࡥࡷࡧ࡯ࡲࡦࡳࡥࠪࡵࠣ࠱ࠥࠫࠨ࡮ࡧࡶࡷࡦ࡭ࡥࠪࡵࠪࠞ"))
    l1l11ll.setFormatter(formatter)
    logger.addHandler(l1l11ll)
    globals()[l11ll (u"ࠢ࡭ࡱࡪ࡫ࡪࡸࠢࠟ")] = logger
def l1l1ll():
    return globals()[l11ll (u"ࠣ࡮ࡲ࡫࡬࡫ࡲࠣࠠ")]
def l1l1111():
    if platform.system() == l11ll (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥࠡ"):
        l11ll (u"ࠥࠦࠧ࡝࡯ࡳ࡭ࡤࡶࡴࡻ࡮ࡥࠢࡥ࡭ࡳࡧࡲࡺࠢ࡬ࡳࠥ࡯࡮ࠡࡹ࡬ࡲࡩࡵࡷࡴࠤࠥࠦࠢ")
        import os
        import l1111l1
        l1111l1.l1lllll(sys.stdin.fileno(), os.l1llll1)
        l1111l1.l1lllll(sys.stdout.fileno(), os.l1llll1)
def l11ll1l(path):
    dirname = os.path.dirname(path)
    if dirname[0] == l11ll (u"ࠦࢃࠨࠣ"):
        dirname = os.path.expanduser(dirname)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    return dirname
def l111l11():
    if platform.system() == l11ll (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠤ"):
        import l1111ll
        return l1111ll.l11l11l()
    elif platform.system() == l11ll (u"ࠨࡌࡪࡰࡸࡼࠧࠥ"):
        return None
    raise ValueError(l11ll (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥࠦ").format(sys.platform))
def l1l():
    if platform.system() == l11ll (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤࠧ"):
        import l1111ll
        return l1111ll.l11111l()
    elif platform.system() == l11ll (u"ࠤࡏ࡭ࡳࡻࡸࠣࠨ"):
        import l1ll11
        return l1ll11.l1l()
    elif platform.system() == l11ll (u"ࠥࡈࡦࡸࡷࡪࡰࠥࠩ"):
        import l1l1l1l
        return l1l1l1l.l1l()
    return l11ll (u"ࠦࡓࡵࡴࠡ࡫ࡰࡴࡱ࡫࡭ࡦࡰࡷࡩࡩࠦࡦࡰࡴࠣࡿ࠵ࢃࠢࠪ").format(sys.platform)
def l11l1l1(l1llll, l1):
    if platform.system() == l11ll (u"ࠧ࡝ࡩ࡯ࡦࡲࡻࡸࠨࠫ"):
        import l1111ll
        return l1111ll.l1l1lll(l1llll, l1)
    elif platform.system() == l11ll (u"ࠨࡄࡢࡴࡺ࡭ࡳࠨࠬ"):
        import l1l1l1l
        return l1l1l1l.l11(l1llll, l1)
    elif platform.system() == l11ll (u"ࠢࡍ࡫ࡱࡹࡽࠨ࠭"):
        import l1ll11
        return l1ll11.l11(l1llll, l1)
    raise ValueError(l11ll (u"ࠣࡐࡲࡸࠥ࡯࡭ࡱ࡮ࡨࡱࡪࡴࡴࡦࡦࠣࡪࡴࡸࠠࡼ࠲ࢀࠦ࠮").format(sys.platform))
def l11ll11(l11l1, url):
    if platform.system() == l11ll (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ࠯"):
        import l1111ll
        return l1111ll.l1lll11(l11l1, url)
    elif platform.system() == l11ll (u"ࠥࡈࡦࡸࡷࡪࡰࠥ࠰"):
        import l1l1l1l
        return l11ll (u"ࠦࡓࡵࡴࠡࡰࡨࡩࡩ࡫ࡤࠣ࠱")
    elif platform.system() == l11ll (u"ࠧࡒࡩ࡯ࡷࡻࠦ࠲"):
        import l1ll11
        return l11ll (u"ࠨࡎࡰࡶࠣࡲࡪ࡫ࡤࡦࡦࠥ࠳")
    raise ValueError(l11ll (u"ࠢࡏࡱࡷࠤ࡮ࡳࡰ࡭ࡧࡰࡩࡳࡺࡥࡥࠢࡩࡳࡷࠦࡻ࠱ࡿࠥ࠴").format(sys.platform))
def l1l1ll1():
    if platform.system() == l11ll (u"࡙ࠣ࡬ࡲࡩࡵࡷࡴࠤ࠵"):
        import l1111ll
        return l1111ll.l1l1ll1()
def l1llllll(obj):
    import json
    return json.dumps(obj)
def get_major_version(version):
    return version.split(l11ll (u"ࠩ࠱ࠫ࠶"))[0]
def l1l1l11(l1l11l):
    l11ll (u"ࠥࠦࠧࡘࡥࡵࡷࡵࡲࡸࠦࡨࡪࡩ࡫ࡩࡸࡺࠠࡱࡴࡲࡸࡴࡩ࡯࡭ࠢ࡬ࡲࠥ࡬࡯ࡳ࡯ࡤࡸ࠿ࠦࡤࡢࡸ࠴࠴ࠥࠨࠢࠣ࠷")
    l1ll1ll = l11ll (u"ࠫࡩࡧࡶ࠱ࠩ࠸")
    for protocol in l1l11l:
        if l11ll (u"ࠬࡶࡲࡰࡶࡲࡧࡴࡲࠧ࠹") in protocol and int(l1ll1ll[3:]) < int(protocol[l11ll (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨ࠺")][3:]):
            l1ll1ll = protocol[l11ll (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩ࠻")]
    return l1ll1ll
def l111ll(l11llll, l11l1ll):
    l11ll (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡅࡲࡱࡵࡧࡲࡦࡵࠣࡸࡼࡵࠠࡴࡱࡩࡸࡼࡧࡲࡦࠢࡹࡩࡷࡹࡩࡰࡰࠣࡲࡺࡳࡢࡦࡴࡶࠤ࠭࡫࠮ࡨ࠰ࠣࠦ࠶࠴࠷࠯࠳ࠥࠤࡴࡸࠠࠣ࠳࠱࠶ࠧ࠯࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠱࠻ࠢࡗ࡬ࡪࠦࡦࡪࡴࡶࡸࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡴࡰࠢࡥࡩࠥࡩ࡯࡮ࡲࡤࡶࡪࡪ࠮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡼ࠲࠻ࠢࡗ࡬ࡪࠦࡳࡦࡥࡲࡲࡩࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡵࡱࠣࡦࡪࠦࡣࡰ࡯ࡳࡥࡷ࡫ࡤ࠯ࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡ࠲ࠣ࡭࡫ࠦࡴࡩࡧࠣࡺࡪࡸࡳࡪࡱࡱࡷࠥࡧࡲࡦࠢࡨࡵࡺࡧ࡬࠭ࠢࡤࠤࡳ࡫ࡧࡢࡶ࡬ࡺࡪࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡪࡨࠣࡺ࠶ࠦ࠼ࠡࡸ࠵࠰ࠥࡧࠠࡱࡱࡶ࡭ࡹ࡯ࡶࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣ࡭࡫࡬ࠠࡷ࠳ࠣࡂࠥࡼ࠲ࠋࠢࠣࠤࠥࠨࠢࠣ࠼")
    if l11llll is None: l11llll = l11ll (u"ࠩ࠳ࠫ࠽");
    if l11l1ll is None: l11l1ll = l11ll (u"ࠪ࠴ࠬ࠾");
    l1ll111 = l11llll.split(l11ll (u"ࠫ࠳࠭࠿"))
    l1lll1l = l11l1ll.split(l11ll (u"ࠬ࠴ࠧࡀ"))
    while len(l1ll111) < len(l1lll1l): l1ll111.append(l11ll (u"ࠨ࠰ࠣࡁ"));
    while len(l1lll1l) < len(l1ll111): l1lll1l.append(l11ll (u"ࠢ࠱ࠤࡂ"));
    l1ll111 = [ int(x) for x in l1ll111 ]
    l1lll1l = [ int(x) for x in l1lll1l ]
    for  i in range(len(l1ll111)):
        if len(l1lll1l) == i:
            return 1
        if l1ll111[i] == l1lll1l[i]:
            continue
        elif l1ll111[i] > l1lll1l[i]:
            return 1
        else:
            return -1
    if len(l1ll111) != len(l1lll1l):
        return -1
    return 0