#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1l1lll = sys.version_info [0] == 2
l1lll1ll = 2048
l111l = 7
def l1lll1l1 (l11l1l1):
    global l11ll11
    l1l1ll1 = ord (l11l1l1 [-1])
    l1l11l1 = l11l1l1 [:-1]
    l11ll = l1l1ll1 % len (l1l11l1)
    l11 = l1l11l1 [:l11ll] + l1l11l1 [l11ll:]
    if l1l1lll:
        l1ll1ll = l1ll1l11 () .join ([unichr (ord (char) - l1lll1ll - (l1lll + l1l1ll1) % l111l) for l1lll, char in enumerate (l11)])
    else:
        l1ll1ll = str () .join ([chr (ord (char) - l1lll1ll - (l1lll + l1l1ll1) % l111l) for l1lll, char in enumerate (l11)])
    return eval (l1ll1ll)
import hashlib
import os
import l1
from l11ll1 import *
import urllib.request, urllib.parse, urllib.error
import grp, pwd
import tempfile
import json
from l1 import l11ll1l
from l1l1 import l1ll11l, l111111
import logging
logger = logging.getLogger(l1lll1l1 (u"ࠦࡩࡵࡣࡶ࡯ࡨࡲࡹࡥ࡯ࡱࡧࡱࡩࡷ࠴࡯ࡱࡧࡵࡥࡹ࡯࡯࡯ࡵࠥࠀ"))
class l11l11():
    def __init__(self, l1llll1,l1lll11l, l1l111l= None, l1l111=None):
        self.l1ll1ll1=False
        self.l1l11l = self._1l1l1l()
        self.l1lll11l = l1lll11l
        self.l1l111l = l1l111l
        self.l1l1l1 = l1llll1
        if l1l111l:
            self.l1l11 = True
        else:
            self.l1l11 = False
        self.l1l111 = l1l111
    def _1l1l1l(self):
        try:
            return l1.l1ll1l1() is not None
        except:
            return False
    def open(self):
        l1lll1l1 (u"ࠬ࠭ࠧࠡ࡯ࡤ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨࠩࠪࠁ")
        if not self.l1l11l:
            raise NotImplementedError(l1lll1l1 (u"ࠨࡕ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡰࡳࡺࡴࡴ࡙ࠡࡨࡦࡉࡇࡖࠡࡨ࡬ࡰࡪࠦࡳࡺࡵࡷࡩࡲࠦࡢࡦࡥࡤࡹࡸ࡫ࠠࡥࡣࡹࡪࡸ࠸ࠠࡪࡵࠣࡲࡴࡺࠠࡪࡰࡶࡸࡦࡲ࡬ࡦࡦ࠱ࠦࠂ"),
                                      l1lll1l1 (u"ࠢࡇ࡫࡯ࡩ࡙ࠥࡹࡴࡶࡨࡱࠥࡓ࡯ࡶࡰࡷ࡭ࡳ࡭ࠠࡆࡴࡵࡳࡷࠨࠃ"))
        l1111 = self.l1l1l1
        if self.l1lll11l.lower().startswith(self.l1l1l1.lower()):
            l1lll11 = re.compile(re.escape(self.l1l1l1), re.IGNORECASE)
            l1lll11l = l1lll11.sub(l1lll1l1 (u"ࠨࠩࠄ"), self.l1lll11l)
            l1lll11l = l1lll11l.replace(l1lll1l1 (u"ࠩࡧࡥࡻ࠭ࠅ"), l1lll1l1 (u"ࠪࡈࡆ࡜ࠧࠆ"))
        self.l111l1l(self.l1l1l1, l1111, l1lll11l, self.l1l111l)
    def l111l1l(self,l1l1l1, l1111, l1lll11l, l1l111l):
        l1lll1l1 (u"ࠫࠬ࠭ࠠࡰࡲࡨࡲࠥࡻࡲ࡭ࠢࠣࠫࠬ࠭ࠇ")
        logger.info(l1lll1l1 (u"ࠧࡕࡰࡦࡰࠣ࡭ࡳࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠢࠈ"))
        l111 = l1lll1l(l1l1l1)
        l1ll111 = self.l1llll(l111)
        logger.info(l1lll1l1 (u"ࠨࡍࡰࡷࡱࡸࠥ࡬࡯࡭ࡦࡨࡶࠥࡶࡡࡵࡪ࠽ࠤࠧࠉ") + l111)
        if l1ll111:
            logger.info(l1lll1l1 (u"ࠢࡎࡱࡸࡲࡹࠦ࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡࡣ࡯ࡶࡪࡧࡤࡺࠢࡨࡼ࡮ࡹࡴࡴࠤࠊ"))
        else:
            l11ll1l(l111)
            l111 = l1llll11(l1l1l1, l1111, l1l111l, self.l1l111)
        logger.debug(l1lll1l1 (u"ࠣࡑࡳࡩࡳࠦࡦࡪ࡮ࡨࠤࡨࡵ࡭࡮ࡣࡱࡨ࠿ࠨࠋ"))
        l1ll11l1=l111 + l1lll1l1 (u"ࠤ࠲ࠦࠌ") + l1lll11l
        l1l1111 = l1lll1l1 (u"ࠥࡼࡩ࡭࠭ࡰࡲࡨࡲࠥࡢࠢࠣࠍ")+l1ll11l1+ l1lll1l1 (u"ࠫࠧ࠭ࠎ")
        logger.debug(l1l1111)
        l11l1l = os.system(l1l1111)
        if (l11l1l != 0):
            raise IOError(l1lll1l1 (u"ࠧࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡤࡰࡥࡸࡱࡪࡴࡴࠡࠧࡶࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠩࡸࠨࠏ") %(l1ll11l1, l11l1l))
    def l1llll(self, l111):
        if os.path.exists(l111):
            if os.path.islink(l111):
                l111 = os.readlink(l111)
            if os.path.ismount(l111):
                return True
        return False
def l1lll1l(l1l1l1):
    l11lll1 = l1l1l1.replace(l1lll1l1 (u"࠭࡜࡝ࠩࠐ"), l1lll1l1 (u"ࠧࡠࠩࠑ")).replace(l1lll1l1 (u"ࠨ࠱ࠪࠒ"), l1lll1l1 (u"ࠩࡢࠫࠓ"))
    l11l11l = l1lll1l1 (u"ࠥ࠲ࡹࡳࡰ࠰ࡹࡨࡦࡩࡧࡶ࠰ࠤࠔ")
    l111l11=os.environ[l1lll1l1 (u"ࠫࡍࡕࡍࡆࠩࠕ")]
    l1ll11ll=os.path.join(l111l11,l11l11l, l11lll1)
    l111ll=os.path.abspath(l1ll11ll)
    return l111ll
def l1ll1lll(l11l):
    if not os.path.exists(l11l):
        os.makedirs(l11l)
def l1l11ll(l1l1l1, l1111, l111ll1=None, password=None):
    l1lll1l1 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡨࠣࡱࡴࡻ࡮ࡵࠢࡺ࡭ࡹ࡮ࠠࡴࡶࡲࡶࡪࡪࠠ࡭ࡱࡪ࡭ࡳࠦࡡ࡯ࡦࠣࡴࡦࡹࡳࡸࡱࡵࡨࠥࡨࡹࠡ࡯ࡨࡸࡴࡪ࡯࡭ࡱࡪࡽࠥࡪࡡࡷࡨࡶࠎࠥࠦࠠࠡࡰࡲࡻࠥࡴ࡯ࡵࠢࡸࡷࡪࡪ࠮ࠡࡨࡲࡶࠥ࡬ࡵࡵࡷࡵࡩࠥࡸࡥࡢ࡮࡬ࡷࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡱࡴࡻ࡮ࡵࡒࡤࡸ࡭ࡀࠠࡱࡣࡷ࡬ࠥ࡬࡯ࡳࠢࡰࡳࡺࡴࡴࡪࡰࡪࠤ࡫࡯࡬ࡦࠢࡲࡶࠥ࡬࡯࡭ࡦࡨࡶࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡶࡩࡷࡼࡥࡳࡗࡵ࡭࠿ࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࡩࡩࡩࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠ࡭ࡱࡪ࡭ࡳࡀࠠ࡭ࡱࡪ࡭ࡳࠦࡦࡰࡴࠣࡱࡴࡻ࡮ࡵࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡢࡵࡶࡻࡴࡸࡤ࠻ࠢࡳࡥࡸࡹࡷࡰࡴࡧࠤ࡫ࡵࡲࠡ࡯ࡲࡹࡳࡺࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠫࠬ࠭ࠖ")
    l11l = l1lll1l(l1l1l1)
    l1ll1lll(l11l)
    if not l111ll1:
        l1llll1l = l1111ll()
        l1111l =l1llll1l.l1lllll1(l1lll1l1 (u"ࠨࡐ࡭ࡧࡤࡷࡪࠦࡳࡱࡧࡦ࡭࡫ࡿࠠࡺࡱࡸࡶࠥࠨࠗ") + l1111 + l1lll1l1 (u"ࠢࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠨ࠘"), l1111 + l1lll1l1 (u"ࠣࠢࡆࡶࡪࡪࡥ࡯ࡶ࡬ࡥࡱࡹࠢ࠙"))
        if not isinstance(l1111l, str):
            l111ll1, password = l1111l
        else:
            raise l111111()
        logger.info(l1lll1l1 (u"ࠤࡗࡶࡾ࡯࡮ࡨࠢࡷࡳࠥࡳ࡯ࡶࡰࡷ࠾ࠥࠨࠚ") + os.path.abspath(l11l))
    l11111 = pwd.getpwuid( os.getuid())[0]
    l1111l1=os.environ[l1lll1l1 (u"ࠪࡌࡔࡓࡅࠨࠛ")]
    l1l1l11=os.path.dirname(os.path.realpath(__file__))
    temp_file=tempfile.NamedTemporaryFile(bufsize=0)
    l1ll11={l1lll1l1 (u"ࠦࡺࡹࡥࡳࡡ࡯ࡳ࡬࡯࡮ࠣࠜ") : l11111, l1lll1l1 (u"ࠧࡳ࡯ࡶࡰࡷࡔࡦࡺࡨࠣࠝ"):l1l1l1, l1lll1l1 (u"ࠨࡤࡪࡴࡓࡥࡹ࡮ࠢࠞ"):l11l, l1lll1l1 (u"ࠢࡩࡱࡰࡩࡤ࡬࡯࡭ࡦࡨࡶࠧࠟ"):l1111l1, l1lll1l1 (u"ࠣ࡯ࡲࡹࡳࡺ࡟ࡶࡵࡨࡶࡤࡲ࡯ࡨ࡫ࡱࠦࠠ"):l111ll1, l1lll1l1 (u"ࠤࡰࡳࡺࡴࡴࡠࡷࡶࡩࡷࡥࡰࡢࡵࡶࠦࠡ"):password}
    try:
        json.dump(l1ll11, temp_file)
        if not os.path.exists(os.path.join(l1l1l11, l1lll1l1 (u"ࠥࡷࡪࡺ࡟࡮ࡱࡸࡲࡹࡥࡤࡪࡵ࡮࠲ࡵࡿ࡯ࠣࠢ"))):
            l111lll=l1lll1l1 (u"ࠦࡵࡿࠢࠣ")
            key=l1lll1l1 (u"ࠧࠨࠤ")
        else:
            l111lll=l1lll1l1 (u"ࠨࡰࡺࡱࠥࠥ")
            key=l1lll1l1 (u"ࠢ࠮ࡑࠣࠦࠦ")
        l1lllll=l1lll1l1 (u"ࠣࡵࡨࡸࡤࡳ࡯ࡶࡰࡷࡣࡩ࡯ࡳ࡬࠰ࠨࡷࠥࠫࡳࠣࠧ") % (l111lll,temp_file.name)
        l1ll1=[l1lll1l1 (u"ࠩࡪ࡯ࡸࡻࡤࡰࠩࠨ"),l1lll1l1 (u"ࠪࡴࡾࡺࡨࡰࡰࠣࠩࡸࠫࡳ࠰ࠧࡶࠫࠩ") %(key, l1l1l11, l1lllll)]
        p = subprocess.Popen(l1ll1, stdout=subprocess.PIPE,stdin=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out, err = p.communicate()
        logger.debug(l1lll1l1 (u"ࠦࡴࡻࡴ࠻ࠢࠨࡷࠧࠪ") %out)
        logger.debug(l1lll1l1 (u"ࠧ࡫ࡲࡳ࠼ࠣࠩࡸࠨࠫ") %err)
    except:
        raise
    finally:
        temp_file.close()
    cmd=l1lll1l1 (u"ࠨ࡭ࡰࡷࡱࡸࠥࠫࡳࠣࠬ") %l11l
    logger.debug(l1lll1l1 (u"ࠢࡎࡱࡸࡲࡹࠦ࡭ࡰࡷࡱࡸ࡫ࡹࠠࡤࡱࡰࡱࡦࡴࡤ࠻ࠤ࠭"))
    logger.debug(cmd)
    result=0
    result = subprocess.call(cmd, shell=True)
    if result != 0:
        logger.error(l1lll1l1 (u"ࠣࡏࡲࡹࡳࡺࡩ࡯ࡩࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴࠣࡧࡴࡪࡥ࠻ࠢࠥ࠮") + str(result))
        raise IOError(l1lll1l1 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠲ࠥࡋࡲࡳࡱࡵࠤࡨࡵࡤࡦ࠼ࠣࠦ࠯") + str(result))
    logger.info(l1lll1l1 (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨ࠰"))
    l111ll=os.path.abspath(l11l)
    logger.debug(l1lll1l1 (u"ࠦࡲࡵࡵ࡯ࡶࡢࡸࡴࡀࠠࠣ࠱")+l111ll)
    return l111ll
def l1llll11(l1l1l1, l1111, l1l111l, l1l111):
    l1lll1l1 (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࡌࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡤࡴࡨࡥࡹ࡫ࠠ࡮ࡱࡸࡲࡹࠦࡳࡦࡴࡹࡩࡷࠦࡴࡰࠢ࡯ࡳࡨࡧ࡬ࠡࡵࡼࡷࡹ࡫࡭ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡳ࡯ࡶࡰࡷࡔࡦࡺࡨ࠻ࠢࡩ࡭ࡱ࡫ࠠࡰࡴࠣࡪࡴࡲࡤࡦࡴࠣࡴࡦࡺࡨࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡹࡥࡳࡸࡨࡶ࡚ࡸࡩ࠻ࠢࡳࡥࡹ࡮ࠠࡧࡱࡵࠤࡲࡵࡵ࡯ࡶ࡬ࡲ࡬ࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡴࡦࡠࡰࡤࡱࡪࡀࠠࡥࡣࡹࡪ࠷ࠦࡣࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࠦࡦࡪ࡮ࡨ࠰ࠥࡶࡡࡴࡵࡨࡨࠥࡧࡳࠡࡰࡸࡰࡱࠦࡦࡰࡴࠣࡒࡔࡔࡅࠡࡅࡒࡓࡐࡏࡅࠡࡣࡸࡸ࡭ࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠪࠫࠬ࠲")
    def l1l1l(title):
        ll=30
        if len(title)>ll:
            l11l1=title.split(l1lll1l1 (u"ࠨ࠯ࠣ࠳"))
            l11l111=l1lll1l1 (u"ࠧࠨ࠴")
            for block in l11l1:
                l11l111+=block+l1lll1l1 (u"ࠣ࠱ࠥ࠵")
                if len(l11l111) > ll:
                    l11l111+=l1lll1l1 (u"ࠤ࠱࠲࠳ࠨ࠶")
                    break
            title=l11l111
        return title
    l111ll1 = l1lll1l1 (u"ࠥࡲࡴࡲ࡯ࡨ࡫ࡱࠦ࠷")
    password = l1lll1l1 (u"ࠦࠧ࠸")
    os.system(l1lll1l1 (u"ࠬ࡬ࡩ࡯ࡦࠣ࠲ࠥ࠳ࡸࡵࡻࡳࡩࠥࡲࠠ࠳ࡀ࠲ࡨࡪࡼ࠯࡯ࡷ࡯ࡰࠥ࠳ࡥࡹࡧࡦࠤࡷࡳࠠࡼࡿࠣࡠࡡࡁࠧ࠹"))
    l1ll1l1l = l1lll1l(l1l1l1)
    l11l = l1lll1l(hashlib.sha1(l1l1l1.encode()).hexdigest()[:10])
    l1ll1lll(l11l)
    logger.info(l1lll1l1 (u"ࠨࡔࡳࡻ࡬ࡲ࡬ࠦࡴࡰࠢࡰࡳࡺࡴࡴ࠻ࠢࠥ࠺") + os.path.abspath(l11l))
    if l1l111l:
        l1llllll = [l1lll1l1 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢ࠻"), l1lll1l1 (u"ࠣ࡯ࡲࡹࡳࡺࠢ࠼"), l1lll1l1 (u"ࠤ࠰ࡸࠧ࠽"), l1lll1l1 (u"ࠪࡨࡦࡼࡦࡴࠩ࠾"), l1lll1l1 (u"ࠫ࠲ࡵࠧ࠿"), l1lll1l1 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠲ࡣࡰࡰࡩࡁࠪࡹࠧࡀ") % (l111ll1, l1l111l),
                    urllib.parse.unquote(l1111), os.path.abspath(l11l)]
    else:
        l111ll1, password = l1lll111(l11l, l1111, l1l111)
        if l111ll1.lower() != l1lll1l1 (u"࠭ࡣࡢࡰࡦࡩࡱ࠭ࡁ"):
            l1llllll = [l1lll1l1 (u"ࠢࡱ࡭ࡨࡼࡪࡩࠢࡂ"), l1lll1l1 (u"ࠣ࡯ࡲࡹࡳࡺࠢࡃ"), l1lll1l1 (u"ࠤ࠰ࡸࠧࡄ"), l1lll1l1 (u"ࠪࡨࡦࡼࡦࡴࠩࡅ"), l1lll1l1 (u"ࠫ࠲ࡵࠧࡆ"), l1lll1l1 (u"ࠬࡻࡩࡥ࠿࡙ࠧࡘࡋࡒ࠭ࡷࡶࡩࡷࡴࡡ࡮ࡧࡀࠩࡸ࠭ࡇ") %l111ll1,
                        urllib.parse.unquote(l1111), os.path.abspath(l11l)]
        else:
            raise l111111()
    logger.info(l1lll1l1 (u"ࠨࡍࡰࡷࡱࡸࠥࡽࡩࡵࡪࠣࡧࡴࡳ࡭ࡢࡰࡧ࠾ࠧࡈ"))
    cmd = l1lll1l1 (u"ࠢࠡࠤࡉ").join(l1llllll)
    logger.info(cmd)
    proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    l1lll1 = l1lll1l1 (u"ࠣࠧࡶࡠࡳࠨࡊ") % password
    out, err = proc.communicate(l1lll1.encode())
    if len(err) > 0:
        l11111l = l1lll1l1 (u"ࠤࡐࡳࡺࡴࡴࡪࡰࡪࠤ࡫ࡧࡩ࡭ࡧࡧ࠾ࠥࠫࡳࠣࡋ") % err.decode()
        logger.error(l11111l)
        raise l1ll11l(l11111l, l1llll11=l1.l1ll1l1(), l1111=l1111)
    logger.info(l1lll1l1 (u"ࠥࡑࡴࡻ࡮ࡵ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡷࡸࠨࡌ"))
    os.system(l1lll1l1 (u"ࠫࡱࡴࠠ࠮ࡵࠣࠦࠪࡹࠢࠡࠤࠨࡷࠧ࠭ࡍ") % (l11l, l1ll1l1l))
    l111ll=os.path.abspath(l1ll1l1l)
    return l111ll
def l1lll111(l1l1l1, l1111, l1l111):
    l11lll = os.path.join(os.environ[l1lll1l1 (u"ࠧࡎࡏࡎࡇࠥࡎ")], l1lll1l1 (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢࡏ"), l1lll1l1 (u"ࠢࡴࡧࡦࡶࡪࡺࡳࠣࡐ"))
    if not os.path.exists(os.path.dirname(l11lll)):
       os.makedirs(os.path.dirname(l11lll))
    l11l1ll = l1l111.get_value(l1lll1l1 (u"ࠨࡒࡨࡶࡲ࡯ࡳࡴ࡫ࡲࡲࡸ࠭ࡑ"), l1lll1l1 (u"ࠩ࡯ࡥࡸࡺ࡟࡭ࡱࡪ࡭ࡳࡥ࡮ࡢ࡯ࡨࠫࡒ"))
    l1llll1l = l1111ll(l1l1l1, l11l1ll)
    l111ll1, password = l1llll1l.l1lllll1(l1lll1l1 (u"ࠥࡔࡱ࡫ࡡࡴࡧࠣࡷࡵ࡫ࡣࡪࡨࡼࠤࡾࡵࡵࡳࠢࠥࡓ") + l1111 + l1lll1l1 (u"ࠦࠥࡩࡲࡦࡦࡨࡲࡹ࡯ࡡ࡭ࡵࠥࡔ"),
                                               l1111 + l1lll1l1 (u"ࠧࠦࡃࡳࡧࡧࡩࡳࡺࡩࡢ࡮ࡶࠦࡕ"))
    if l111ll1 != l1lll1l1 (u"࠭࡮ࡰ࡮ࡲ࡫࡮ࡴࠧࡖ") and not l1ll(l1l1l1, l111ll1):
        l111l1 = l1lll1l1 (u"ࠢࠡࠤࡗ").join([l1l1l1, l111ll1, l1lll1l1 (u"ࠨࠤࠪࡘ") + password + l1lll1l1 (u"࡙ࠩࠥࠫ"), l1lll1l1 (u"ࠪࡠࡳ࡚࠭")])
        with open(l11lll, l1lll1l1 (u"ࠫࡼ࠱࡛ࠧ")) as l11llll:
            l11llll.write(l111l1)
        os.chmod(l11lll, 0o600)
    return l111ll1, password
def l1ll(l1l1l1, l111ll1):
    l11lll = l1ll1l = os.path.join(os.environ[l1lll1l1 (u"ࠧࡎࡏࡎࡇࠥ࡜")], l1lll1l1 (u"ࠨ࠮ࡥࡣࡹࡪࡸ࠸ࠢ࡝"), l1lll1l1 (u"ࠢࡴࡧࡦࡶࡪࡺࡳࠣ࡞"))
    if os.path.exists(l11lll):
        with open(l11lll, l1lll1l1 (u"ࠣࡴࠥ࡟")) as f:
            data = f.readlines()
            l1l = data[0].split(l1lll1l1 (u"ࠤࠣࠦࡠ"))
            if l1l1l1 == l1l[0] and l111ll1 == l1l[1]:
                return True
    return False