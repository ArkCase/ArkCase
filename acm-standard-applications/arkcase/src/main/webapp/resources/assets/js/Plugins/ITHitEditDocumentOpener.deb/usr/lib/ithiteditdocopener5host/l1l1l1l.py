#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
l1ll = sys.version_info [0] == 2
l1111l = 2048
l1l1l = 7
def l11ll (l1l1):
    global l11l1l
    ll = ord (l1l1 [-1])
    l1l1l1 = l1l1 [:-1]
    l11l = ll % len (l1l1l1)
    l11l11 = l1l1l1 [:l11l] + l1l1l1 [l11l:]
    if l1ll:
        l111l1 = l1lll1 () .join ([unichr (ord (char) - l1111l - (l111l + ll) % l1l1l) for l111l, char in enumerate (l11l11)])
    else:
        l111l1 = str () .join ([chr (ord (char) - l1111l - (l111l + ll) % l1l1l) for l111l, char in enumerate (l11l11)])
    return eval (l111l1)
import l1111
from l1l1l111 import l1l1l11l
import objc as _111llll
from CoreFoundation import CFStringCreateWithCString, CFURLCreateWithString, kCFAllocatorDefault, kCFStringEncodingUTF8
import LaunchServices
try:
    _111llll.l111l1l1( LaunchServices.__bundle__, LaunchServices.__dict__, [
        (l11ll (u"ࠬࡒࡓࡄࡱࡳࡽࡉ࡫ࡦࡢࡷ࡯ࡸࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡗࡕࡐࡋࡵࡲࡖࡔࡏࠫࢩ"), LaunchServices._111lll1.l111111l(l1111ll1 (u"࠭࡞ࡼࡡࡢࡇࡋ࡛ࡒࡍ࠿ࢀࡢࢀࡥ࡟ࡄࡈࡘࡖࡑࡃࡽࡍࡠࡡࡿࡤࡥࡃࡇࡇࡵࡶࡴࡸ࠽ࡾࠩࢪ"), l1111ll1 (u"ࠧ࡟ࡽࡢࡣࡈࡌࡕࡓࡎࡀࢁࡣࢁ࡟ࡠࡅࡉ࡙ࡗࡒ࠽ࡾࡋࡡࡢࢀࡥ࡟ࡄࡈࡈࡶࡷࡵࡲ࠾ࡿࠪࢫ")), l11ll (u"ࠨࠩࢬ"), {l11ll (u"ࠩࡵࡩࡹࡼࡡ࡭ࠩࢭ"): {l11ll (u"ࠪࡥࡱࡸࡥࡢࡦࡼࡣࡨ࡬ࡲࡦࡶࡤ࡭ࡳ࡫ࡤࠨࢮ"): True}, l11ll (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧࢯ"): {2: {l11ll (u"ࠬࡴࡵ࡭࡮ࡢࡥࡨࡩࡥࡱࡶࡨࡨࠬࢰ"): True, l11ll (u"࠭ࡡ࡭ࡴࡨࡥࡩࡿ࡟ࡤࡨࡵࡩࡹࡧࡩ࡯ࡧࡧࠫࢱ"): True, l11ll (u"ࠧࡵࡻࡳࡩࡤࡳ࡯ࡥ࡫ࡩ࡭ࡪࡸࠧࢲ"): l11ll (u"ࠨࡱࠪࢳ")}}}),
        ])
except:
    pass
def l11111l1(l1111111):
    l1111111 = (l1111111 + l11ll (u"ࠩ࠽ࠫࢴ")).encode()
    l11111ll = CFStringCreateWithCString( kCFAllocatorDefault, l1111111, kCFStringEncodingUTF8 )
    l111l11l = CFURLCreateWithString( kCFAllocatorDefault, l11111ll, _111llll.nil )
    l1111l1l = LaunchServices.l1111lll( l111l11l, LaunchServices.l111ll1l, _111llll.nil )
    if l1111l1l[0] is not None:
        return True
    return False
def l1l():
    l1111l11 = []
    for name in l1l1l11l:
        try:
            if l11111l1(name):
                l1111l11.append(name)
        except:
            continue
    return l1111l11
def l11(l1llll, l1):
    import plistlib
    import os
    l1lll = []
    l1l11l = {}
    for l111l111 in os.listdir(l11ll (u"ࠥ࠳ࡆࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵࠥࢵ")):
        if l111l111.startswith(l1):
            try:
                l111ll11 = l11ll (u"ࠦ࠴ࡇࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶ࠳ࠪࡹ࠯ࡄࡱࡱࡸࡪࡴࡴࡴ࠱ࡌࡲ࡫ࡵ࠮ࡱ࡮࡬ࡷࡹࠨࢶ") % l111l111
                with open(l111ll11, l11ll (u"ࠬࡸࡢࠨࢷ")) as f:
                    plist = plistlib.load(f)
                    l11l1 = plist[l11ll (u"ࠨࡃࡇࡄࡸࡲࡩࡲࡥࡖࡔࡏࡘࡾࡶࡥࡴࠤࢸ")][0][l11ll (u"ࠢࡄࡈࡅࡹࡳࡪ࡬ࡦࡗࡕࡐࡘࡩࡨࡦ࡯ࡨࡷࠧࢹ")][0]
                    version = plist[l11ll (u"ࠣࡅࡉࡆࡺࡴࡤ࡭ࡧ࡙ࡩࡷࡹࡩࡰࡰࠥࢺ")]
                    l111l1ll = version.split(l11ll (u"ࠤ࠱ࠦࢻ"))[0]
                    if l1llll == l111l1ll:
                        if not l11l1 in l1l11l:
                            l1l11l[l11l1] = version
                        elif l1111.l111ll(version, l1l11l[l11l1]) > 0:
                            l1l11l[l11l1] = version
            except BaseException:
                continue
    for l11l1 in l1l11l:
        l1lll.append({l11ll (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫࢼ"): l1l11l[l11l1], l11ll (u"ࠫࡵࡸ࡯ࡵࡱࡦࡳࡱ࠭ࢽ"): l11l1})
    return l1lll